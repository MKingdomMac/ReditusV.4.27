#include "ReditusMovementPrompt.h"

#include "../ATB/ReditusATBComponent.h"
#include "ReditusBattleHUDPresenterComponent.h"
#include "ReditusBattleHUDWidget.h"
#include "Blueprint/WidgetTree.h"
#include "Brushes/SlateColorBrush.h"
#include "Components/ActorComponent.h"
#include "Components/Border.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/HorizontalBox.h"
#include "Components/HorizontalBoxSlot.h"
#include "Components/Image.h"
#include "Components/SizeBox.h"
#include "Components/TextBlock.h"
#include "Engine/GameViewportClient.h"
#include "Engine/LocalPlayer.h"
#include "Engine/Texture2D.h"
#include "Engine/World.h"
#include "Framework/Application/IInputProcessor.h"
#include "Framework/Application/SlateApplication.h"
#include "GameFramework/Actor.h"
#include "GameFramework/PlayerController.h"
#include "HAL/PlatformTime.h"
#include "Input/Events.h"
#include "InputCoreTypes.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Layout/WidgetPath.h"
#include "Styling/CoreStyle.h"
#include "UObject/UnrealType.h"
#include "Widgets/SViewport.h"

DEFINE_LOG_CATEGORY_STATIC(LogReditusTutorialPrompt, Log, All);

namespace ReditusMovementPrompt
{
    constexpr double DurationSeconds = 4.5;
    constexpr int32 ViewportZOrder = 30;
    constexpr int32 BlockZOrder = 60;
    constexpr float StickDeadZone = 0.30f;
    constexpr float AnalogChangeThreshold = 0.12f;

    #include "ReditusMovementPromptGlyphs.inl"

    UTexture2D* LoadGlyph(UObject* WorldContext, const uint8* Png, int32 ByteCount)
    {
        const TArray<uint8> Buffer(Png, ByteCount);
        return UKismetRenderingLibrary::ImportBufferAsTexture2D(WorldContext, Buffer);
    }

    const TCHAR* ProgressSlot(const UWorld& World)
    {
        return World.WorldType == EWorldType::PIE ? TEXT("ReditusBlockTutorial_PIE") : TEXT("ReditusBlockTutorial");
    }

    UReditusMovementPromptSubsystem* FindSubsystem(const UObject* Context, APlayerController*& OutPlayer)
    {
        OutPlayer = IsValid(Context) ? UGameplayStatics::GetPlayerController(Context, 0) : nullptr;
        ULocalPlayer* LocalPlayer = IsValid(OutPlayer) ? OutPlayer->GetLocalPlayer() : nullptr;
        return LocalPlayer ? LocalPlayer->GetSubsystem<UReditusMovementPromptSubsystem>() : nullptr;
    }
}

class FReditusMovementPromptInputObserver final : public IInputProcessor
{
public:
    explicit FReditusMovementPromptInputObserver(UReditusMovementPromptSubsystem* Subsystem)
        : Owner(Subsystem)
    {
    }

    void Tick(float, FSlateApplication&, TSharedRef<ICursor>) override
    {
        if (UReditusMovementPromptSubsystem* Subsystem = Owner.Get())
        {
            Subsystem->TickPrompt();
        }
    }

    bool HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& Event) override
    {
        if (!Event.IsRepeat() && CanObserve(SlateApp, Event.GetUserIndex()))
        {
            Owner->RecordDevice(Event.GetKey().IsGamepadKey());
        }
        return false;
    }

    bool HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& Event) override
    {
        if (CanObserve(SlateApp, Event.GetUserIndex()))
        {
            Owner->RecordDevice(false);
        }
        return false;
    }

    bool HandleAnalogInputEvent(FSlateApplication& SlateApp, const FAnalogInputEvent& Event) override
    {
        const FKey Key = Event.GetKey();
        const float Value = Event.GetAnalogValue();
        if (!Key.IsGamepadKey() || !FMath::IsFinite(Value) || !CanObserve(SlateApp, Event.GetUserIndex()))
        {
            return false;
        }

        float& LastSignificantValue = PreviousAnalogValues.FindOrAdd(Key);
        if (FMath::Abs(Value) < ReditusMovementPrompt::StickDeadZone)
        {
            LastSignificantValue = 0.f;
        }
        else if (FMath::Abs(Value - LastSignificantValue) >= ReditusMovementPrompt::AnalogChangeThreshold)
        {
            LastSignificantValue = Value;
            Owner->RecordDevice(true);
        }
        return false;
    }

private:
    bool CanObserve(FSlateApplication& SlateApp, uint32 UserIndex) const
    {
        const UReditusMovementPromptSubsystem* Subsystem = Owner.Get();
        const ULocalPlayer* LocalPlayer = Subsystem ? Subsystem->GetLocalPlayer() : nullptr;
        if (!LocalPlayer || !LocalPlayer->ViewportClient || !SlateApp.IsActive()
            || LocalPlayer->GetControllerId() != static_cast<int32>(UserIndex))
        {
            return false;
        }

        const TSharedPtr<SViewport> GameViewport = LocalPlayer->ViewportClient->GetGameViewportWidget();
        if (!GameViewport.IsValid())
        {
            return false;
        }

        const TSharedPtr<SWidget> FocusedWidget = SlateApp.GetUserFocusedWidget(static_cast<int32>(UserIndex));
        FWidgetPath FocusPath;
        return FocusedWidget.IsValid() && SlateApp.GeneratePathToWidgetUnchecked(
            FocusedWidget.ToSharedRef(), FocusPath, EVisibility::All)
            && FocusPath.ContainsWidget(GameViewport.ToSharedRef());
    }

    TWeakObjectPtr<UReditusMovementPromptSubsystem> Owner;
    TMap<FKey, float> PreviousAnalogValues;
};

void UReditusMovementPromptWidget::SetGlyph(UTexture2D* Texture, bool bGamepad)
{
    CurrentGlyph = Texture;
    bGamepadGlyph = bGamepad;
    bBlockPrompt = false;
    RefreshGlyph();
}

void UReditusMovementPromptWidget::SetBlockPrompt(UTexture2D* Texture, const FText& KeyLabel)
{
    CurrentGlyph = Texture;
    BlockKeyLabel = KeyLabel;
    bBlockPrompt = true;
    RefreshGlyph();
}

void UReditusMovementPromptWidget::RefreshGlyph()
{
    if (!GlyphImage || !GlyphBounds || !PromptCaption || !KeyCaption || !KeyCap || !PromptPlacement)
    {
        return;
    }

    GlyphBounds->SetVisibility(CurrentGlyph ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
    GlyphImage->SetBrushFromTexture(CurrentGlyph);
    KeyCap->SetVisibility(bBlockPrompt && !CurrentGlyph
        ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
    KeyCaption->SetText(BlockKeyLabel);

    if (bBlockPrompt)
    {
        PromptPlacement->SetAnchors(FAnchors(0.5f, 0.66f));
        PromptPlacement->SetAlignment(FVector2D(0.5f, 0.5f));
        PromptPlacement->SetPosition(FVector2D(0.f, 0.f));
        GlyphBounds->SetWidthOverride(52.f);
        GlyphBounds->SetHeightOverride(52.f);
        PromptCaption->SetText(NSLOCTEXT("ReditusMovementPrompt", "BlockNow", "Block now"));
        return;
    }

    PromptPlacement->SetAnchors(FAnchors(0.5f, 1.f));
    PromptPlacement->SetAlignment(FVector2D(0.5f, 1.f));
    PromptPlacement->SetPosition(FVector2D(0.f, -65.f));
    GlyphBounds->SetWidthOverride(72.f);
    GlyphBounds->SetHeightOverride(72.f);
    if (CurrentGlyph)
    {
        PromptCaption->SetText(NSLOCTEXT("ReditusMovementPrompt", "Move", "Move"));
    }
    else
    {
        PromptCaption->SetText(bGamepadGlyph
            ? NSLOCTEXT("ReditusMovementPrompt", "MoveWithStick", "Move  [Left stick]")
            : NSLOCTEXT("ReditusMovementPrompt", "MoveWithKeyboard", "Move  [WASD]"));
    }
}

TSharedRef<SWidget> UReditusMovementPromptWidget::RebuildWidget()
{
    if (!WidgetTree)
    {
        WidgetTree = NewObject<UWidgetTree>(this);
    }

    if (!WidgetTree->RootWidget)
    {
        UCanvasPanel* PromptCanvas = WidgetTree->ConstructWidget<UCanvasPanel>();
        WidgetTree->RootWidget = PromptCanvas;

        UBorder* PromptBackground = WidgetTree->ConstructWidget<UBorder>();
        PromptBackground->SetBrush(FSlateColorBrush(FLinearColor(0.011f, 0.022f, 0.040f, 0.76f)));
        PromptBackground->SetPadding(FMargin(14.f, 4.f, 22.f, 4.f));

        UHorizontalBox* PromptRow = WidgetTree->ConstructWidget<UHorizontalBox>();
        PromptBackground->SetContent(PromptRow);

        GlyphBounds = WidgetTree->ConstructWidget<USizeBox>();
        GlyphBounds->SetWidthOverride(72.f);
        GlyphBounds->SetHeightOverride(72.f);
        GlyphImage = WidgetTree->ConstructWidget<UImage>();
        GlyphBounds->SetContent(GlyphImage);
        UHorizontalBoxSlot* GlyphRowSlot = PromptRow->AddChildToHorizontalBox(GlyphBounds);
        GlyphRowSlot->SetPadding(FMargin(0.f, 0.f, 12.f, 0.f));
        GlyphRowSlot->SetVerticalAlignment(VAlign_Center);

        KeyCap = WidgetTree->ConstructWidget<UBorder>();
        KeyCap->SetBrush(FSlateColorBrush(FLinearColor(0.10f, 0.16f, 0.22f, 0.95f)));
        KeyCap->SetPadding(FMargin(11.f, 6.f, 11.f, 6.f));
        KeyCaption = WidgetTree->ConstructWidget<UTextBlock>();
        KeyCaption->SetFont(FCoreStyle::GetDefaultFontStyle(TEXT("Bold"), 16));
        KeyCaption->SetColorAndOpacity(FSlateColor(FLinearColor(1.f, 0.74f, 0.34f, 1.f)));
        KeyCap->SetContent(KeyCaption);
        UHorizontalBoxSlot* KeyRowSlot = PromptRow->AddChildToHorizontalBox(KeyCap);
        KeyRowSlot->SetPadding(FMargin(0.f, 0.f, 12.f, 0.f));
        KeyRowSlot->SetVerticalAlignment(VAlign_Center);

        PromptCaption = WidgetTree->ConstructWidget<UTextBlock>();
        PromptCaption->SetFont(FCoreStyle::GetDefaultFontStyle(TEXT("Bold"), 20));
        PromptCaption->SetColorAndOpacity(FSlateColor(FLinearColor(1.f, 0.93f, 0.77f, 1.f)));
        PromptCaption->SetShadowColorAndOpacity(FLinearColor(0.f, 0.f, 0.f, 0.8f));
        PromptCaption->SetShadowOffset(FVector2D(1.f, 1.f));
        PromptRow->AddChildToHorizontalBox(PromptCaption)->SetVerticalAlignment(VAlign_Center);

        PromptPlacement = PromptCanvas->AddChildToCanvas(PromptBackground);
        PromptPlacement->SetAutoSize(true);
    }

    SetVisibility(ESlateVisibility::HitTestInvisible);
    RefreshGlyph();
    return Super::RebuildWidget();
}

void UReditusMovementPromptSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    RegisterInputObserver();
}

void UReditusMovementPromptSubsystem::Deinitialize()
{
    CancelBlockTutorial();
    DismissPrompt();
    if (InputObserver.IsValid() && FSlateApplication::IsInitialized())
    {
        FSlateApplication::Get().UnregisterInputPreProcessor(InputObserver);
    }
    InputObserver.Reset();
    Super::Deinitialize();
}

void UReditusMovementPromptSubsystem::RegisterInputObserver()
{
    if (!InputObserver.IsValid() && FSlateApplication::IsInitialized())
    {
        const TSharedPtr<IInputProcessor> Observer = MakeShared<FReditusMovementPromptInputObserver>(this);
        if (FSlateApplication::Get().RegisterInputPreProcessor(Observer, 0))
        {
            InputObserver = Observer;
        }
    }
}

void UReditusMovementPromptSubsystem::ShowPrompt(APlayerController& OwningController)
{
    if (bShowingBlockPrompt || !EnsurePrompt(OwningController))
    {
        return;
    }

    if (!bHasObservedDevice)
    {
        const FBoolProperty* KeyboardState =
            FindFProperty<FBoolProperty>(OwningController.GetClass(), TEXT("IsUsingKeyboard"));
        bLastInputWasGamepad = KeyboardState && !KeyboardState->GetPropertyValue_InContainer(&OwningController);
    }

    if (!KeyboardGlyph)
    {
        KeyboardGlyph = ReditusMovementPrompt::LoadGlyph(&OwningController, ReditusMovementPrompt::KeyboardPng,
            UE_ARRAY_COUNT(ReditusMovementPrompt::KeyboardPng));
    }
    if (!GamepadGlyph)
    {
        GamepadGlyph = ReditusMovementPrompt::LoadGlyph(&OwningController, ReditusMovementPrompt::GamepadPng,
            UE_ARRAY_COUNT(ReditusMovementPrompt::GamepadPng));
    }

    ActivePrompt->SetGlyph(bLastInputWasGamepad ? GamepadGlyph : KeyboardGlyph, bLastInputWasGamepad);
    if (DisplayPrompt(OwningController, ReditusMovementPrompt::ViewportZOrder))
    {
        DismissAt = FPlatformTime::Seconds() + ReditusMovementPrompt::DurationSeconds;
    }
}

bool UReditusMovementPromptSubsystem::EnsurePrompt(APlayerController& OwningController)
{
    RegisterInputObserver();
    UWorld* World = OwningController.GetWorld();
    if (!InputObserver.IsValid() || !World)
    {
        return false;
    }
    if (IsValid(ActivePrompt) && ActivePrompt->IsInViewport()
        && PromptWorld.Get() == World && ActivePrompt->GetOwningPlayer() == &OwningController)
    {
        return true;
    }

    DismissPrompt();
    ActivePrompt = CreateWidget<UReditusMovementPromptWidget>(&OwningController);
    return IsValid(ActivePrompt);
}

bool UReditusMovementPromptSubsystem::DisplayPrompt(APlayerController& OwningController, int32 ZOrder)
{
    if (!ActivePrompt->IsInViewport() && !ActivePrompt->AddToPlayerScreen(ZOrder))
    {
        DismissPrompt();
        return false;
    }
    PromptWorld = OwningController.GetWorld();
    return true;
}

void UReditusMovementPromptSubsystem::ArmBlockTutorial(AActor& BattleController, APlayerController& OwningController)
{
    UWorld* World = BattleController.GetWorld();
    if (!World || World != OwningController.GetWorld())
    {
        return;
    }

    if (!bBlockProgressLoaded)
    {
        const auto* Progress = Cast<UReditusBlockTutorialSave>(
            UGameplayStatics::LoadGameFromSlot(ReditusMovementPrompt::ProgressSlot(*World), 0));
        bBlockCompleted = Progress && Progress->bCompleted;
        bBlockProgressLoaded = true;
    }
    if (bBlockCompleted)
    {
        return;
    }

    const auto* Presenter = BattleController.FindComponentByClass<UReditusBattleHUDPresenterComponent>();
    UReditusBattleHUDWidget* BattleHUD = Presenter ? Presenter->HUD : nullptr;
    if (!IsValid(BattleHUD) || !BattleHUD->IsInViewport() || BattleHUD->GetOwningPlayer() != &OwningController)
    {
        UE_LOG(LogReditusTutorialPrompt, Warning, TEXT("Arm Block Tutorial after the local battle HUD is on screen."));
        return;
    }
    if (bBlockBattleArmed && BlockBattleHUD.Get() == BattleHUD && BlockBattleController.Get() == &BattleController)
    {
        return;
    }

    CancelBlockTutorial();
    BlockBattleController = &BattleController;
    BlockBattleHUD = BattleHUD;
    bBlockBattleArmed = true;
    RegisterInputObserver();
}

bool UReditusMovementPromptSubsystem::IsBlockBattleActive() const
{
    const auto* BattleController = BlockBattleController.Get();
    const auto* BattleHUD = BlockBattleHUD.Get();
    const auto* LocalPlayer = GetLocalPlayer();
    const auto* World = LocalPlayer ? LocalPlayer->GetWorld() : nullptr;
    return bBlockBattleArmed && !bBlockCompleted && World
        && IsValid(BattleController) && BattleController->GetWorld() == World
        && IsValid(BattleHUD) && BattleHUD->IsInViewport() && BattleHUD->GetWorld() == World;
}

void UReditusMovementPromptSubsystem::ShowBlockTutorialPrompt(AActor& Attacker, APlayerController& OwningController)
{
    if (bShowingBlockPrompt || !IsBlockBattleActive() || Attacker.GetWorld() != OwningController.GetWorld())
    {
        return;
    }

    DismissPrompt();
    if (!EnsurePrompt(OwningController))
    {
        return;
    }

    BlockAttacker = &Attacker;
    bShowingBlockPrompt = true;
    RefreshBlockGlyph();
    if (!DisplayPrompt(OwningController, ReditusMovementPrompt::BlockZOrder))
    {
        CancelBlockTutorial();
    }
}

void UReditusMovementPromptSubsystem::RefreshBlockGlyph()
{
    const auto* BattleHUD = BlockBattleHUD.Get();
    if (!IsValid(BattleHUD) || !IsValid(ActivePrompt))
    {
        return;
    }

    const bool bGamepad = BattleHUD->GetInputDevice() == EReditusHUDInputDevice::Xbox;
    const FKey Binding = bGamepad ? BattleHUD->GamepadKeys.Block : BattleHUD->KeyboardBlockKey;
    const FKey BlockKey = Binding.IsValid() ? Binding : (bGamepad ? EKeys::Gamepad_LeftShoulder : EKeys::SpaceBar);
    if (DisplayedBlockKey == BlockKey)
    {
        return;
    }

    DisplayedBlockKey = BlockKey;
    UTexture2D* Glyph = BattleHUD->GlyphTextures.FindRef(BlockKey.GetFName());
    const FText Caption = BlockKey == EKeys::Gamepad_LeftShoulder
        ? NSLOCTEXT("ReditusMovementPrompt", "LeftShoulder", "LB") : BlockKey.GetDisplayName();
    ActivePrompt->SetBlockPrompt(Glyph, Caption);
}

bool UReditusMovementPromptSubsystem::HoldBlockTutorialBite(AActor& Attacker, AActor& Defender,
    UActorComponent& AttackAnimation, bool bDefenderIsDefending, const FReditusHeldTutorialBite& ApplyBite)
{
    if (!bShowingBlockPrompt || !IsBlockBattleActive() || BlockAttacker.Get() != &Attacker)
    {
        return false;
    }
    if (bHoldingBite)
    {
        return true;
    }
    UWorld* World = Attacker.GetWorld();
    if (!World || Defender.GetWorld() != World || AttackAnimation.GetOwner() != &Attacker || !ApplyBite.IsBound())
    {
        UE_LOG(LogReditusTutorialPrompt, Warning, TEXT("Hold Block Tutorial Bite needs the current defender, the attacker's animation component and a bound bite event."));
        CancelBlockTutorial();
        return false;
    }
    if (bDefenderIsDefending && EarlyBlockDefender.Get() == &Defender)
    {
        CompleteBlockTutorial(*World, ApplyBite);
        return true;
    }

    HeldDefender = &Defender;
    HeldBite = ApplyBite;
    HeldAnimation = &AttackAnimation;
    bAnimationWasTicking = AttackAnimation.IsComponentTickEnabled();
    bHoldingBite = true;
    AttackAnimation.SetComponentTickEnabled(false);
    if (auto* ATB = BlockBattleController->FindComponentByClass<UReditusATBComponent>())
    {
        HeldATB = ATB;
        bATBWasPaused = ATB->bPaused;
        ATB->bPaused = true;
    }
    return true;
}

void UReditusMovementPromptSubsystem::NotifyBlockTutorialDefense(AActor& Defender)
{
    UWorld* World = Defender.GetWorld();
    if (!bShowingBlockPrompt || !IsBlockBattleActive() || !World || World != PromptWorld.Get())
    {
        return;
    }
    if (!bHoldingBite)
    {
        EarlyBlockDefender = &Defender;
        return;
    }
    if (HeldDefender.Get() != &Defender || !HeldBite.IsBound())
    {
        return;
    }

    // The Blueprint's existing IsDefending delay starts after this call returns.
    CompleteBlockTutorial(*World, HeldBite);
}

void UReditusMovementPromptSubsystem::CompleteBlockTutorial(const UWorld& World, FReditusHeldTutorialBite ReleaseBite)
{
    const TCHAR* SlotName = ReditusMovementPrompt::ProgressSlot(World);
    bBlockCompleted = true;
    CancelBlockTutorial();
    ReleaseBite.ExecuteIfBound();

    auto* Progress = Cast<UReditusBlockTutorialSave>(
        UGameplayStatics::CreateSaveGameObject(UReditusBlockTutorialSave::StaticClass()));
    if (Progress)
    {
        Progress->bCompleted = true;
    }
    if (!Progress || !UGameplayStatics::SaveGameToSlot(Progress, SlotName, 0))
    {
        UE_LOG(LogReditusTutorialPrompt, Warning, TEXT("Could not save Block tutorial completion."));
    }
}

void UReditusMovementPromptSubsystem::CancelBlockTutorial()
{
    if (auto* Animation = HeldAnimation.Get())
    {
        Animation->SetComponentTickEnabled(bAnimationWasTicking);
    }
    if (auto* ATB = HeldATB.Get())
    {
        ATB->bPaused = bATBWasPaused;
    }
    HeldAnimation.Reset();
    HeldATB.Reset();
    HeldDefender.Reset();
    HeldBite.Unbind();
    BlockAttacker.Reset();
    EarlyBlockDefender.Reset();
    BlockBattleController.Reset();
    BlockBattleHUD.Reset();
    bHoldingBite = false;
    bBlockBattleArmed = false;
    if (bShowingBlockPrompt)
    {
        DismissPrompt();
    }
}

void UReditusMovementPromptSubsystem::RecordDevice(bool bGamepad)
{
    bHasObservedDevice = true;
    if (bLastInputWasGamepad == bGamepad)
    {
        return;
    }

    bLastInputWasGamepad = bGamepad;
    if (IsValid(ActivePrompt) && !bShowingBlockPrompt)
    {
        ActivePrompt->SetGlyph(bGamepad ? GamepadGlyph : KeyboardGlyph, bGamepad);
    }
}

void UReditusMovementPromptSubsystem::TickPrompt()
{
    if (bBlockBattleArmed && (!IsBlockBattleActive()
        || (bShowingBlockPrompt && (!BlockAttacker.IsValid() || !IsValid(ActivePrompt) || !ActivePrompt->IsInViewport()))
        || (bHoldingBite && (!HeldAnimation.IsValid() || !HeldDefender.IsValid() || !HeldBite.IsBound()))))
    {
        CancelBlockTutorial();
    }
    if (!ActivePrompt)
    {
        return;
    }
    const ULocalPlayer* LocalPlayer = GetLocalPlayer();
    if (!IsValid(ActivePrompt) || !ActivePrompt->IsInViewport() || !PromptWorld.IsValid()
        || !LocalPlayer || PromptWorld.Get() != LocalPlayer->GetWorld())
    {
        DismissPrompt();
        return;
    }
    if (bShowingBlockPrompt)
    {
        RefreshBlockGlyph();
    }
    else if (FPlatformTime::Seconds() >= DismissAt)
    {
        DismissPrompt();
    }
}

void UReditusMovementPromptSubsystem::DismissPrompt()
{
    if (IsValid(ActivePrompt))
    {
        ActivePrompt->RemoveFromParent();
    }
    ActivePrompt = nullptr;
    PromptWorld.Reset();
    bShowingBlockPrompt = false;
    DisplayedBlockKey = FKey();
}

void UReditusMovementPromptLibrary::ShowMovementTutorialPrompt(const UObject* WorldContextObject)
{
    APlayerController* Player = nullptr;
    if (auto* Subsystem = ReditusMovementPrompt::FindSubsystem(WorldContextObject, Player))
    {
        Subsystem->ShowPrompt(*Player);
    }
}

void UReditusMovementPromptLibrary::ArmBlockTutorial(AActor* BattleController)
{
    APlayerController* Player = nullptr;
    if (auto* Subsystem = ReditusMovementPrompt::FindSubsystem(BattleController, Player))
    {
        Subsystem->ArmBlockTutorial(*BattleController, *Player);
    }
}

void UReditusMovementPromptLibrary::ShowBlockTutorialPrompt(AActor* Attacker)
{
    APlayerController* Player = nullptr;
    if (auto* Subsystem = ReditusMovementPrompt::FindSubsystem(Attacker, Player))
    {
        Subsystem->ShowBlockTutorialPrompt(*Attacker, *Player);
    }
}

bool UReditusMovementPromptLibrary::HoldBlockTutorialBite(AActor* Attacker, AActor* Defender,
    UActorComponent* AttackAnimation, bool bDefenderIsDefending, FReditusHeldTutorialBite ApplyBite)
{
    APlayerController* Player = nullptr;
    auto* Subsystem = ReditusMovementPrompt::FindSubsystem(Attacker, Player);
    return Subsystem && IsValid(Defender) && IsValid(AttackAnimation)
        && Subsystem->HoldBlockTutorialBite(*Attacker, *Defender, *AttackAnimation, bDefenderIsDefending, ApplyBite);
}

void UReditusMovementPromptLibrary::NotifyBlockTutorialDefense(AActor* Defender)
{
    APlayerController* Player = nullptr;
    if (auto* Subsystem = ReditusMovementPrompt::FindSubsystem(Defender, Player))
    {
        Subsystem->NotifyBlockTutorialDefense(*Defender);
    }
}
