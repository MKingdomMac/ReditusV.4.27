#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "GameFramework/SaveGame.h"
#include "InputCoreTypes.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Subsystems/LocalPlayerSubsystem.h"
#include "ReditusMovementPrompt.generated.h"

class AActor;
class APlayerController;
class FReditusMovementPromptInputObserver;
class IInputProcessor;
class UActorComponent;
class UBorder;
class UCanvasPanelSlot;
class UImage;
class UReditusATBComponent;
class UReditusBattleHUDWidget;
class USizeBox;
class UTextBlock;
class UTexture2D;
class UWorld;

DECLARE_DYNAMIC_DELEGATE(FReditusHeldTutorialBite);

UCLASS()
class CHAPTER1REDITUS_API UReditusBlockTutorialSave : public USaveGame
{
    GENERATED_BODY()

public:
    UPROPERTY(SaveGame)
    bool bCompleted = false;
};

UCLASS(NotBlueprintable, Transient)
class CHAPTER1REDITUS_API UReditusMovementPromptWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    void SetGlyph(UTexture2D* Texture, bool bGamepad);
    void SetBlockPrompt(UTexture2D* Texture, const FText& KeyLabel);

protected:
    virtual TSharedRef<SWidget> RebuildWidget() override;

private:
    void RefreshGlyph();

    UPROPERTY(Transient)
    UTexture2D* CurrentGlyph = nullptr;

    UPROPERTY(Transient)
    UImage* GlyphImage = nullptr;

    UPROPERTY(Transient)
    USizeBox* GlyphBounds = nullptr;

    UPROPERTY(Transient)
    UTextBlock* PromptCaption = nullptr;

    UPROPERTY(Transient)
    UTextBlock* KeyCaption = nullptr;

    UPROPERTY(Transient)
    UBorder* KeyCap = nullptr;

    UPROPERTY(Transient)
    UCanvasPanelSlot* PromptPlacement = nullptr;

    FText BlockKeyLabel;
    bool bGamepadGlyph = false;
    bool bBlockPrompt = false;
};

UCLASS()
class CHAPTER1REDITUS_API UReditusMovementPromptSubsystem : public ULocalPlayerSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    void ShowPrompt(APlayerController& OwningController);
    void ArmBlockTutorial(AActor& BattleController, APlayerController& OwningController);
    void ShowBlockTutorialPrompt(AActor& Attacker, APlayerController& OwningController);
    bool HoldBlockTutorialBite(AActor& Attacker, AActor& Defender, UActorComponent& AttackAnimation,
        bool bDefenderIsDefending, const FReditusHeldTutorialBite& ApplyBite);
    void NotifyBlockTutorialDefense(AActor& Defender);

private:
    friend class FReditusMovementPromptInputObserver;

    void RegisterInputObserver();
    void RecordDevice(bool bGamepad);
    bool EnsurePrompt(APlayerController& OwningController);
    bool DisplayPrompt(APlayerController& OwningController, int32 ZOrder);
    void TickPrompt();
    void DismissPrompt();
    bool IsBlockBattleActive() const;
    void RefreshBlockGlyph();
    void CompleteBlockTutorial(const UWorld& World, FReditusHeldTutorialBite ReleaseBite);
    void CancelBlockTutorial();

    UPROPERTY(Transient)
    UReditusMovementPromptWidget* ActivePrompt = nullptr;

    UPROPERTY(Transient)
    UTexture2D* KeyboardGlyph = nullptr;

    UPROPERTY(Transient)
    UTexture2D* GamepadGlyph = nullptr;

    TSharedPtr<IInputProcessor> InputObserver;
    TWeakObjectPtr<UWorld> PromptWorld;
    TWeakObjectPtr<AActor> BlockBattleController;
    TWeakObjectPtr<UReditusBattleHUDWidget> BlockBattleHUD;
    TWeakObjectPtr<AActor> BlockAttacker;
    TWeakObjectPtr<AActor> EarlyBlockDefender;
    TWeakObjectPtr<AActor> HeldDefender;
    TWeakObjectPtr<UActorComponent> HeldAnimation;
    TWeakObjectPtr<UReditusATBComponent> HeldATB;
    FReditusHeldTutorialBite HeldBite;
    FKey DisplayedBlockKey;
    double DismissAt = 0.0;
    bool bHasObservedDevice = false;
    bool bLastInputWasGamepad = false;
    bool bShowingBlockPrompt = false;
    bool bBlockBattleArmed = false;
    bool bBlockProgressLoaded = false;
    bool bBlockCompleted = false;
    bool bHoldingBite = false;
    bool bAnimationWasTicking = false;
    bool bATBWasPaused = false;
};

UCLASS()
class CHAPTER1REDITUS_API UReditusMovementPromptLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    /** Show the movement hint for the local player for 4.5 seconds. */
    UFUNCTION(BlueprintCallable, Category = "Reditus|Tutorial",
        meta = (WorldContext = "WorldContextObject", DisplayName = "Show Movement Tutorial Prompt"))
    static void ShowMovementTutorialPrompt(const UObject* WorldContextObject);

    /** Call once from the tutorial encounter after its battle HUD has been added to the screen. */
    UFUNCTION(BlueprintCallable, Category = "Reditus|Tutorial")
    static void ArmBlockTutorial(AActor* BattleController);

    /** Call from the lizard's warning notify. */
    UFUNCTION(BlueprintCallable, Category = "Reditus|Tutorial")
    static void ShowBlockTutorialPrompt(AActor* Attacker);

    /** True means this node handled the bite. If false, apply the bite normally. */
    UFUNCTION(BlueprintCallable, Category = "Reditus|Tutorial")
    static bool HoldBlockTutorialBite(AActor* Attacker, AActor* Defender, UActorComponent* AttackAnimation,
        bool bDefenderIsDefending, FReditusHeldTutorialBite ApplyBite);

    /** Call immediately after the block input sets the target's IsDefending flag. */
    UFUNCTION(BlueprintCallable, Category = "Reditus|Tutorial")
    static void NotifyBlockTutorialDefense(AActor* Defender);
};
