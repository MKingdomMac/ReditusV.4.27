// Copyright 2017 ~ 2022 Critical Failure Studio Ltd. All rights reserved.

#include "AnimNodes/PaperZDAnimNode_PlaySequence.h"
#include "AnimSequences/Players/PaperZDAnimPlayer.h"

FPaperZDAnimNode_PlaySequence::FPaperZDAnimNode_PlaySequence()
	: AnimSequence(nullptr)
	, PlayRate(1.0f)
	, StartPosition(0.0f)
	, bLoopAnimation(true)
	, PlaybackTime(0.0f)
{}

void FPaperZDAnimNode_PlaySequence::OnInitialize(const FPaperZDAnimationInitContext& InitContext)
{
	if (AnimSequence)
	{
		//Initialize the starting time
		const float SeqDuration = AnimSequence->GetTotalDuration();
		PlaybackTime = PlayRate < 0.0f ? SeqDuration : FMath::Min(StartPosition, SeqDuration);
	}
}

void FPaperZDAnimNode_PlaySequence::OnUpdate(const FPaperZDAnimationUpdateContext& UpdateContext)
{
	if (AnimSequence)
	{
		//Independent of the weight we have, we should update the playback, to avoid losing sync
		UPaperZDAnimPlayer* Player = UpdateContext.AnimInstance->GetPlayer();
		Player->TickPlayback(AnimSequence, PlaybackTime, UpdateContext.DeltaTime * PlayRate, bLoopAnimation, UpdateContext.AnimInstance, UpdateContext.Weight);		
	}
}

void FPaperZDAnimNode_PlaySequence::OnEvaluate(FPaperZDAnimationPlaybackData& OutData)
{
	if (AnimSequence)
	{
		//Forcefully add the animation as the only present
		OutData.SetAnimation(AnimSequence, PlaybackTime);
	}
}
