// Copyright Epic Games, Inc. All Rights Reserved.

#include "TileMapEdModeToolkit.h"
#include "TileMapEdMode.h"
#include "TileMapTerrainActor.h"

#include "AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "EditorModeManager.h"

#include "Engine/Level.h"
#include "Engine/Selection.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/World.h"
#include "EngineUtils.h"

#include "IAssetTools.h"
#include "Materials/Material.h"
#include "Materials/MaterialInterface.h"

#include "Misc/MessageDialog.h"
#include "Modules/ModuleManager.h"
#include "PhysicsEngine/BodySetup.h"
#include "ProceduralMeshComponent.h"
#include "RawMesh.h"
#include "ScopedTransaction.h"
#include "UObject/Package.h"

#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSpinBox.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "FTileMapEdModeToolkit"

namespace TileMapEdModeToolkitLocal
{
	struct FExposedFace
	{
		FIntVector NeighborOffset;
		FVector Normal;
		FVector Corners[4];
	};

	ATileMapTerrainActor* FindTerrainActor(UWorld* EditorWorld)
	{
		if (!EditorWorld)
		{
			return nullptr;
		}

		if (GEditor)
		{
			USelection* SelectedActors =
				GEditor->GetSelectedActors();

			if (SelectedActors)
			{
				for (
					FSelectionIterator It(*SelectedActors);
					It;
					++It
					)
				{
					ATileMapTerrainActor* TerrainActor =
						Cast<ATileMapTerrainActor>(*It);

					if (
						TerrainActor &&
						TerrainActor->GetWorld() == EditorWorld
						)
					{
						return TerrainActor;
					}
				}
			}
		}

		for (
			TActorIterator<ATileMapTerrainActor> It(EditorWorld);
			It;
			++It
			)
		{
			return *It;
		}

		return nullptr;
	}

	void AddRawMeshFace(
		FRawMesh& RawMesh,
		const FVector* Corners,
		const FVector& Normal,
		int32 MaterialIndex
	)
	{
		uint32 VertexIndices[4];

		for (int32 CornerIndex = 0; CornerIndex < 4; ++CornerIndex)
		{
			VertexIndices[CornerIndex] =
				RawMesh.VertexPositions.Add(
					Corners[CornerIndex]
				);
		}

		static const int32 TriangleCorners[6] =
		{
			0, 2, 1,
			0, 3, 2
		};

		static const FVector2D CornerUVs[4] =
		{
			FVector2D(0.0f, 0.0f),
			FVector2D(1.0f, 0.0f),
			FVector2D(1.0f, 1.0f),
			FVector2D(0.0f, 1.0f)
		};

		const FVector TangentX =
			(Corners[1] - Corners[0]).GetSafeNormal();

		const FVector TangentY =
			FVector::CrossProduct(
				Normal,
				TangentX
			).GetSafeNormal();

		for (int32 WedgeIndex = 0; WedgeIndex < 6; ++WedgeIndex)
		{
			const int32 CornerIndex =
				TriangleCorners[WedgeIndex];

			RawMesh.WedgeIndices.Add(
				VertexIndices[CornerIndex]
			);

			RawMesh.WedgeTangentX.Add(TangentX);
			RawMesh.WedgeTangentY.Add(TangentY);
			RawMesh.WedgeTangentZ.Add(Normal);
			RawMesh.WedgeTexCoords[0].Add(
				CornerUVs[CornerIndex]
			);
			RawMesh.WedgeColors.Add(FColor::White);
		}

		for (int32 TriangleIndex = 0; TriangleIndex < 2; ++TriangleIndex)
		{
			RawMesh.FaceMaterialIndices.Add(MaterialIndex);
			RawMesh.FaceSmoothingMasks.Add(0);
		}
	}

	void AddRawMeshTriangle(
		FRawMesh& RawMesh,
		const FVector& Corner0,
		const FVector& Corner1,
		const FVector& Corner2,
		const FVector& Normal,
		int32 MaterialIndex
	)
	{
		const FVector Corners[3] =
		{
			Corner0,
			Corner1,
			Corner2
		};

		uint32 VertexIndices[3];

		for (int32 CornerIndex = 0; CornerIndex < 3; ++CornerIndex)
		{
			VertexIndices[CornerIndex] =
				RawMesh.VertexPositions.Add(Corners[CornerIndex]);
		}

		static const int32 TriangleCorners[3] = { 0, 2, 1 };
		static const FVector2D CornerUVs[3] =
		{
			FVector2D(0.0f, 0.0f),
			FVector2D(1.0f, 0.0f),
			FVector2D(1.0f, 1.0f)
		};

		const FVector TangentX =
			(Corner1 - Corner0).GetSafeNormal();

		const FVector TangentY =
			FVector::CrossProduct(
				Normal,
				TangentX
			).GetSafeNormal();

		for (int32 WedgeIndex = 0; WedgeIndex < 3; ++WedgeIndex)
		{
			const int32 CornerIndex = TriangleCorners[WedgeIndex];

			RawMesh.WedgeIndices.Add(VertexIndices[CornerIndex]);
			RawMesh.WedgeTangentX.Add(TangentX);
			RawMesh.WedgeTangentY.Add(TangentY);
			RawMesh.WedgeTangentZ.Add(Normal);
			RawMesh.WedgeTexCoords[0].Add(CornerUVs[CornerIndex]);
			RawMesh.WedgeColors.Add(FColor::White);
		}

		RawMesh.FaceMaterialIndices.Add(MaterialIndex);
		RawMesh.FaceSmoothingMasks.Add(0);
	}

	struct FDiagonalBoundaryPoint
	{
		FVector2D BasePoint;
		FVector2D WavyPoint;
		FVector2D OutwardNormal;
	};

	struct FDiagonalRoundedCorner
	{
		FVector2D Center;
		FVector2D TangentIn;
		FVector2D TangentOut;
		float StartAngle;
		float EndAngle;
	};

	void AddRawMeshPolygon(
		FRawMesh& RawMesh,
		const TArray<FVector>& Boundary,
		const FVector& Normal,
		int32 MaterialIndex,
		bool bReverseWinding
	)
	{
		if (Boundary.Num() < 3)
		{
			return;
		}

		FVector Center = FVector::ZeroVector;

		for (const FVector& Point : Boundary)
		{
			Center += Point;
		}

		Center /= static_cast<float>(Boundary.Num());

		for (int32 PointIndex = 0;
			PointIndex < Boundary.Num();
			++PointIndex)
		{
			const int32 NextPointIndex =
				(PointIndex + 1) % Boundary.Num();

			if (bReverseWinding)
			{
				AddRawMeshTriangle(
					RawMesh,
					Center,
					Boundary[NextPointIndex],
					Boundary[PointIndex],
					Normal,
					MaterialIndex
				);
			}
			else
			{
				AddRawMeshTriangle(
					RawMesh,
					Center,
					Boundary[PointIndex],
					Boundary[NextPointIndex],
					Normal,
					MaterialIndex
				);
			}
		}
	}

	void BuildDiagonalBoundary(
		const FVector2D* Triangle,
		int32 EdgeSubdivisions,
		int32 CornerSubdivisions,
		float CornerRadius,
		float EdgeIrregularity,
		float EdgeWavelength,
		TArray<FDiagonalBoundaryPoint>& OutBoundary
	)
	{
		OutBoundary.Reset();
		FDiagonalRoundedCorner Corners[3];
		const float ShortestTriangleEdge = FMath::Min(
			FMath::Min(
				(Triangle[1] - Triangle[0]).Size(),
				(Triangle[2] - Triangle[1]).Size()
			),
			(Triangle[0] - Triangle[2]).Size()
		);

		for (int32 CornerIndex = 0;
			CornerIndex < 3;
			++CornerIndex)
		{
			const FVector2D& Vertex = Triangle[CornerIndex];
			const FVector2D& Previous =
				Triangle[(CornerIndex + 2) % 3];
			const FVector2D& Next =
				Triangle[(CornerIndex + 1) % 3];
			const FVector2D DirectionToPrevious =
				(Previous - Vertex).GetSafeNormal();
			const FVector2D DirectionToNext =
				(Next - Vertex).GetSafeNormal();
			const float InteriorAngle = FMath::Acos(
				FMath::Clamp(
					FVector2D::DotProduct(
						DirectionToPrevious,
						DirectionToNext
					),
					-1.0f,
					1.0f
				)
			);
			const float HalfAngle = InteriorAngle * 0.5f;
			const float MaximumTangentDistance = FMath::Min(
				FMath::Min(
					(Previous - Vertex).Size(),
					(Next - Vertex).Size()
				) * 0.2f,
				FMath::Max(ShortestTriangleEdge * 1.5f, 0.5f)
			);
			const float DesiredTangentDistance =
				CornerRadius /
				FMath::Max(
					FMath::Tan(HalfAngle),
					KINDA_SMALL_NUMBER
				);
			const float TangentDistance = FMath::Clamp(
				DesiredTangentDistance,
				0.5f,
				FMath::Max(MaximumTangentDistance, 0.5f)
			);
			const float ActualRadius =
				TangentDistance * FMath::Tan(HalfAngle);
			const FVector2D Bisector =
				(DirectionToPrevious + DirectionToNext)
				.GetSafeNormal();

			FDiagonalRoundedCorner& Corner = Corners[CornerIndex];
			Corner.TangentIn =
				Vertex + DirectionToPrevious * TangentDistance;
			Corner.TangentOut =
				Vertex + DirectionToNext * TangentDistance;
			Corner.Center =
				Vertex +
				Bisector *
				(
					ActualRadius /
					FMath::Max(
						FMath::Sin(HalfAngle),
						KINDA_SMALL_NUMBER
					)
				);
			Corner.StartAngle = FMath::Atan2(
				Corner.TangentIn.Y - Corner.Center.Y,
				Corner.TangentIn.X - Corner.Center.X
			);
			Corner.EndAngle = FMath::Atan2(
				Corner.TangentOut.Y - Corner.Center.Y,
				Corner.TangentOut.X - Corner.Center.X
			);

			while (Corner.EndAngle <= Corner.StartAngle)
			{
				Corner.EndAngle += 2.0f * PI;
			}
		}

		const int32 SafeEdgeSubdivisions = FMath::Max(
			EdgeSubdivisions,
			2
		);
		const int32 SafeCornerSubdivisions = FMath::Max(
			CornerSubdivisions,
			2
		);
		const float SafeWavelength = FMath::Max(
			EdgeWavelength,
			1.0f
		);

		for (int32 CornerIndex = 0;
			CornerIndex < 3;
			++CornerIndex)
		{
			const FDiagonalRoundedCorner& Corner =
				Corners[CornerIndex];
			const float ArcAngle =
				Corner.EndAngle - Corner.StartAngle;
			const int32 ArcSteps = FMath::Max(
				2,
				FMath::RoundToInt(
					SafeCornerSubdivisions *
					ArcAngle /
					(PI * 0.5f)
				)
			);

			for (int32 ArcStep = 0;
				ArcStep <= ArcSteps;
				++ArcStep)
			{
				const float Alpha =
					static_cast<float>(ArcStep) /
					static_cast<float>(ArcSteps);
				const float Angle = FMath::Lerp(
					Corner.StartAngle,
					Corner.EndAngle,
					Alpha
				);
				const FVector2D OutwardNormal(
					FMath::Cos(Angle),
					FMath::Sin(Angle)
				);
				const float Radius =
					(Corner.TangentIn - Corner.Center).Size();
				const FVector2D BasePoint =
					Corner.Center + OutwardNormal * Radius;

				OutBoundary.Add(
					FDiagonalBoundaryPoint
					{
						BasePoint,
						BasePoint,
						OutwardNormal
					}
				);
			}

			const int32 EdgeIndex = CornerIndex;
			const FDiagonalRoundedCorner& NextCorner =
				Corners[(CornerIndex + 1) % 3];
			const FVector2D EdgeStart = Corner.TangentOut;
			const FVector2D EdgeEnd = NextCorner.TangentIn;
			const FVector2D EdgeVector = EdgeEnd - EdgeStart;
			const FVector2D EdgeTangent =
				EdgeVector.GetSafeNormal();
			const FVector2D OutwardNormal(
				EdgeTangent.Y,
				-EdgeTangent.X
			);

			for (int32 EdgeStep = 1;
				EdgeStep < SafeEdgeSubdivisions;
				++EdgeStep)
			{
				const float Alpha =
					static_cast<float>(EdgeStep) /
					static_cast<float>(SafeEdgeSubdivisions);
				const FVector2D BasePoint = FMath::Lerp(
					EdgeStart,
					EdgeEnd,
					Alpha
				);
				FVector2D WavyPoint = BasePoint;

				// Edge 2 is the physical diagonal cliff boundary. The two
				// orthogonal edges remain exact so neighboring grid cells still
				// meet them without seams. The wave fades to zero before each
				// rounded endpoint so the transition stays tangent and watertight.
				if (
					EdgeIndex == 2 &&
					EdgeIrregularity > KINDA_SMALL_NUMBER
					)
				{
					const float TangentCoordinate =
						FVector2D::DotProduct(
							BasePoint,
							EdgeTangent
						);
					const float PrimaryAngle =
						2.0f * PI *
						TangentCoordinate /
						SafeWavelength;
					const float SecondaryAngle =
						2.0f * PI *
						TangentCoordinate /
						(SafeWavelength * 0.61f) +
						1.234f;
					const float Noise =
						0.75f * FMath::Sin(PrimaryAngle) +
						0.25f * FMath::Sin(SecondaryAngle);
					const float EndpointBlend = FMath::Square(
						FMath::Sin(PI * Alpha)
					);

					WavyPoint +=
						OutwardNormal *
						Noise *
						EdgeIrregularity *
						EndpointBlend;
				}

				OutBoundary.Add(
					FDiagonalBoundaryPoint
					{
						BasePoint,
						WavyPoint,
						OutwardNormal
					}
				);
			}
		}
	}

	int32 FindOrAddMaterial(
		TArray<UMaterialInterface*>& Materials,
		UMaterialInterface* Material
	)
	{
		if (!Material)
		{
			Material = UMaterial::GetDefaultMaterial(MD_Surface);
		}

		const int32 ExistingIndex =
			Materials.IndexOfByKey(Material);

		return ExistingIndex != INDEX_NONE
			? ExistingIndex
			: Materials.Add(Material);
	}

	bool AppendStaticMeshGeometry(
		UStaticMesh* SourceMesh,
		UMaterialInterface* SlotZeroOverride,
		const FTransform& LocalTransform,
		FRawMesh& OutRawMesh,
		TArray<UMaterialInterface*>& OutMaterials
	)
	{
		if (
			!SourceMesh ||
			SourceMesh->GetNumSourceModels() <= 0
			)
		{
			return false;
		}

		const FStaticMeshSourceModel& SourceModel =
			SourceMesh->GetSourceModel(0);

		if (!SourceModel.RawMeshBulkData)
		{
			return false;
		}

		FRawMesh SourceRawMesh;
		SourceModel.RawMeshBulkData->LoadRawMesh(
			SourceRawMesh
		);

		if (
			SourceRawMesh.VertexPositions.Num() == 0 ||
			SourceRawMesh.WedgeIndices.Num() == 0
			)
		{
			return false;
		}

		const uint32 VertexOffset =
			static_cast<uint32>(
				OutRawMesh.VertexPositions.Num()
			);

		for (const FVector& Position : SourceRawMesh.VertexPositions)
		{
			OutRawMesh.VertexPositions.Add(
				LocalTransform.TransformPosition(Position)
			);
		}

		const int32 WedgeCount =
			SourceRawMesh.WedgeIndices.Num();

		for (int32 WedgeIndex = 0; WedgeIndex < WedgeCount; ++WedgeIndex)
		{
			OutRawMesh.WedgeIndices.Add(
				VertexOffset +
				SourceRawMesh.WedgeIndices[WedgeIndex]
			);

			const FVector SourceTangentX =
				SourceRawMesh.WedgeTangentX.IsValidIndex(WedgeIndex)
				? SourceRawMesh.WedgeTangentX[WedgeIndex]
				: FVector::ForwardVector;

			const FVector SourceTangentY =
				SourceRawMesh.WedgeTangentY.IsValidIndex(WedgeIndex)
				? SourceRawMesh.WedgeTangentY[WedgeIndex]
				: FVector::RightVector;

			const FVector SourceTangentZ =
				SourceRawMesh.WedgeTangentZ.IsValidIndex(WedgeIndex)
				? SourceRawMesh.WedgeTangentZ[WedgeIndex]
				: FVector::UpVector;

			OutRawMesh.WedgeTangentX.Add(
				LocalTransform
				.TransformVectorNoScale(SourceTangentX)
				.GetSafeNormal()
			);

			OutRawMesh.WedgeTangentY.Add(
				LocalTransform
				.TransformVectorNoScale(SourceTangentY)
				.GetSafeNormal()
			);

			OutRawMesh.WedgeTangentZ.Add(
				LocalTransform
				.TransformVectorNoScale(SourceTangentZ)
				.GetSafeNormal()
			);

			OutRawMesh.WedgeTexCoords[0].Add(
				SourceRawMesh.WedgeTexCoords[0]
				.IsValidIndex(WedgeIndex)
				? SourceRawMesh.WedgeTexCoords[0][WedgeIndex]
				: FVector2D::ZeroVector
			);

			OutRawMesh.WedgeColors.Add(
				SourceRawMesh.WedgeColors.IsValidIndex(WedgeIndex)
				? SourceRawMesh.WedgeColors[WedgeIndex]
				: FColor::White
			);
		}

		const int32 TriangleCount = WedgeCount / 3;

		for (
			int32 TriangleIndex = 0;
			TriangleIndex < TriangleCount;
			++TriangleIndex
			)
		{
			const int32 SourceMaterialIndex =
				SourceRawMesh.FaceMaterialIndices
				.IsValidIndex(TriangleIndex)
				? SourceRawMesh.FaceMaterialIndices[TriangleIndex]
				: 0;

			UMaterialInterface* Material =
				SourceMaterialIndex == 0 && SlotZeroOverride
				? SlotZeroOverride
				: SourceMesh->GetMaterial(SourceMaterialIndex);

			OutRawMesh.FaceMaterialIndices.Add(
				FindOrAddMaterial(
					OutMaterials,
					Material
				)
			);

			OutRawMesh.FaceSmoothingMasks.Add(
				SourceRawMesh.FaceSmoothingMasks
				.IsValidIndex(TriangleIndex)
				? SourceRawMesh.FaceSmoothingMasks[TriangleIndex]
				: 0
			);
		}

		return true;
	}

	bool AppendProceduralMeshGeometry(
		UProceduralMeshComponent* SourceComponent,
		FRawMesh& OutRawMesh,
		TArray<UMaterialInterface*>& OutMaterials
	)
	{
		if (!SourceComponent)
		{
			return false;
		}

		bool bAppendedGeometry = false;
		const FTransform LocalTransform =
			SourceComponent->GetRelativeTransform();

		for (
			int32 SectionIndex = 0;
			SectionIndex < SourceComponent->GetNumSections();
			++SectionIndex
			)
		{
			const FProcMeshSection* Section =
				SourceComponent->GetProcMeshSection(SectionIndex);

			if (
				!Section ||
				Section->ProcVertexBuffer.Num() == 0 ||
				Section->ProcIndexBuffer.Num() == 0
				)
			{
				continue;
			}

			const uint32 VertexOffset =
				static_cast<uint32>(
					OutRawMesh.VertexPositions.Num()
				);

			for (
				const FProcMeshVertex& Vertex :
				Section->ProcVertexBuffer
				)
			{
				OutRawMesh.VertexPositions.Add(
					LocalTransform.TransformPosition(
						Vertex.Position
					)
				);
			}

			for (
				const uint32 SourceVertexIndex :
				Section->ProcIndexBuffer
				)
			{
				if (
					!Section->ProcVertexBuffer.IsValidIndex(
						static_cast<int32>(SourceVertexIndex)
					)
					)
				{
					return false;
				}

				const FProcMeshVertex& Vertex =
					Section->ProcVertexBuffer[
						static_cast<int32>(SourceVertexIndex)
					];

				const FVector TangentX =
					LocalTransform
					.TransformVectorNoScale(
						Vertex.Tangent.TangentX
					)
					.GetSafeNormal();
				const FVector TangentZ =
					LocalTransform
					.TransformVectorNoScale(Vertex.Normal)
					.GetSafeNormal();
				const FVector TangentY =
					FVector::CrossProduct(
						TangentZ,
						TangentX
					).GetSafeNormal() *
					(Vertex.Tangent.bFlipTangentY ? -1.0f : 1.0f);

				OutRawMesh.WedgeIndices.Add(
					VertexOffset + SourceVertexIndex
				);
				OutRawMesh.WedgeTangentX.Add(TangentX);
				OutRawMesh.WedgeTangentY.Add(TangentY);
				OutRawMesh.WedgeTangentZ.Add(TangentZ);
				OutRawMesh.WedgeTexCoords[0].Add(Vertex.UV0);
				OutRawMesh.WedgeColors.Add(Vertex.Color);
			}

			const int32 MaterialIndex = FindOrAddMaterial(
				OutMaterials,
				SourceComponent->GetMaterial(SectionIndex)
			);
			const int32 TriangleCount =
				Section->ProcIndexBuffer.Num() / 3;

			for (
				int32 TriangleIndex = 0;
				TriangleIndex < TriangleCount;
				++TriangleIndex
				)
			{
				OutRawMesh.FaceMaterialIndices.Add(MaterialIndex);
				OutRawMesh.FaceSmoothingMasks.Add(0);
			}

			bAppendedGeometry = true;
		}

		return bAppendedGeometry;
	}

	bool BuildOptimizedRawMesh(
		ATileMapTerrainActor* TerrainActor,
		FRawMesh& OutRawMesh,
		TArray<UMaterialInterface*>& OutMaterials
	)
	{
		if (
			!TerrainActor ||
			TerrainActor->OccupiedBlocks.Num() == 0
			)
		{
			return false;
		}

		if (TerrainActor->bUseContinuousTerrainPrototype)
		{
			bool bAppendedGeometry = false;

			TInlineComponentArray<UProceduralMeshComponent*>
				ContinuousComponents(TerrainActor);

			for (
				UProceduralMeshComponent* ContinuousComponent :
				ContinuousComponents
				)
			{
				if (
					!IsValid(ContinuousComponent) ||
					!ContinuousComponent->GetName().StartsWith(
						TEXT("TileContinuousChunk_")
					)
					)
				{
					continue;
				}

				bAppendedGeometry =
					AppendProceduralMeshGeometry(
						ContinuousComponent,
						OutRawMesh,
						OutMaterials
					) ||
					bAppendedGeometry;
			}

			for (
				const FIntVector& GridPosition :
				TerrainActor->OccupiedBlocks
				)
			{
				if (TerrainActor->IsContinuousSurfaceBlock(GridPosition))
				{
					continue;
				}

				const int32 TileType =
					TerrainActor->GetBlockTileType(GridPosition);

				bAppendedGeometry =
					AppendStaticMeshGeometry(
						TerrainActor->GetTileMesh(TileType),
						TerrainActor->GetTileMaterialOverride(
							TileType
						),
						TerrainActor->GetBlockLocalTransform(
							GridPosition
						),
						OutRawMesh,
						OutMaterials
					) ||
					bAppendedGeometry;
			}

			return
				bAppendedGeometry &&
				OutRawMesh.WedgeIndices.Num() > 0 &&
				OutMaterials.Num() > 0 &&
				OutRawMesh.IsValidOrFixable();
		}

		const float Size =
			FMath::Max(TerrainActor->GridSize, 1.0f);

		const bool bDefaultTileIsEngineCube =
			TerrainActor->BlockMesh &&
			TerrainActor->BlockMesh->GetPathName() ==
			TEXT("/Engine/BasicShapes/Cube.Cube");

		const FExposedFace Faces[6] =
		{
			{
				FIntVector(1, 0, 0),
				FVector(1.0f, 0.0f, 0.0f),
				{
					FVector(1.0f, 0.0f, 0.0f),
					FVector(1.0f, 1.0f, 0.0f),
					FVector(1.0f, 1.0f, 1.0f),
					FVector(1.0f, 0.0f, 1.0f)
				}
			},
			{
				FIntVector(-1, 0, 0),
				FVector(-1.0f, 0.0f, 0.0f),
				{
					FVector(0.0f, 1.0f, 0.0f),
					FVector(0.0f, 0.0f, 0.0f),
					FVector(0.0f, 0.0f, 1.0f),
					FVector(0.0f, 1.0f, 1.0f)
				}
			},
			{
				FIntVector(0, 1, 0),
				FVector(0.0f, 1.0f, 0.0f),
				{
					FVector(1.0f, 1.0f, 0.0f),
					FVector(0.0f, 1.0f, 0.0f),
					FVector(0.0f, 1.0f, 1.0f),
					FVector(1.0f, 1.0f, 1.0f)
				}
			},
			{
				FIntVector(0, -1, 0),
				FVector(0.0f, -1.0f, 0.0f),
				{
					FVector(0.0f, 0.0f, 0.0f),
					FVector(1.0f, 0.0f, 0.0f),
					FVector(1.0f, 0.0f, 1.0f),
					FVector(0.0f, 0.0f, 1.0f)
				}
			},
			{
				FIntVector(0, 0, 1),
				FVector(0.0f, 0.0f, 1.0f),
				{
					FVector(0.0f, 0.0f, 1.0f),
					FVector(1.0f, 0.0f, 1.0f),
					FVector(1.0f, 1.0f, 1.0f),
					FVector(0.0f, 1.0f, 1.0f)
				}
			},
			{
				FIntVector(0, 0, -1),
				FVector(0.0f, 0.0f, -1.0f),
				{
					FVector(0.0f, 1.0f, 0.0f),
					FVector(1.0f, 1.0f, 0.0f),
					FVector(1.0f, 0.0f, 0.0f),
					FVector(0.0f, 0.0f, 0.0f)
				}
			}
		};

		TSet<FIntVector> BakedBlocks;

		for (
			const FIntVector& GridPosition :
			TerrainActor->OccupiedBlocks
			)
		{
			if (BakedBlocks.Contains(GridPosition))
			{
				continue;
			}

			BakedBlocks.Add(GridPosition);

			const int32 TileType =
				TerrainActor->GetBlockTileType(GridPosition);

			UStaticMesh* TileMesh =
				TerrainActor->GetTileMesh(TileType);

			UMaterialInterface* MaterialOverride =
				TerrainActor->GetTileMaterialOverride(TileType);

			// Preserve the existing exposed-face optimization for the default
			// engine cube. Modular palette meshes keep their complete geometry.
			if (!(TileType == 0 && bDefaultTileIsEngineCube))
			{
				if (
					!AppendStaticMeshGeometry(
						TileMesh,
						MaterialOverride,
						TerrainActor->GetBlockLocalTransform(
							GridPosition
						),
						OutRawMesh,
						OutMaterials
					)
					)
				{
					return false;
				}

				continue;
			}

			UMaterialInterface* CubeMaterial =
				MaterialOverride
				? MaterialOverride
				: TileMesh->GetMaterial(0);

			const int32 CubeMaterialIndex =
				FindOrAddMaterial(
					OutMaterials,
					CubeMaterial
				);

			const FVector BlockMinimum(
				GridPosition.X * Size,
				GridPosition.Y * Size,
				GridPosition.Z * Size
			);

			for (const FExposedFace& Face : Faces)
			{
				const FIntVector NeighborPosition =
					GridPosition + Face.NeighborOffset;

				if (
					TerrainActor->HasBlock(NeighborPosition) &&
					TerrainActor->GetBlockTileType(
						NeighborPosition
					) == 0
					)
				{
					continue;
				}

				FVector FaceCorners[4];

				for (
					int32 CornerIndex = 0;
					CornerIndex < 4;
					++CornerIndex
					)
				{
					FaceCorners[CornerIndex] =
						BlockMinimum +
						(Face.Corners[CornerIndex] * Size);
				}

					AddRawMeshFace(
						OutRawMesh,
						FaceCorners,
						Face.Normal,
						CubeMaterialIndex
					);
			}
		}

		return
			OutRawMesh.WedgeIndices.Num() > 0 &&
			OutMaterials.Num() > 0 &&
			OutRawMesh.IsValidOrFixable();
	}

	UStaticMesh* BakeTerrainToStaticMesh(
		ATileMapTerrainActor* TerrainActor
	)
	{
		FRawMesh RawMesh;
		TArray<UMaterialInterface*> Materials;

		if (
			!BuildOptimizedRawMesh(
				TerrainActor,
				RawMesh,
				Materials
			)
			)
		{
			return nullptr;
		}

		FString PackageName;
		FString AssetName;

		FAssetToolsModule& AssetToolsModule =
			FModuleManager::LoadModuleChecked<
				FAssetToolsModule
			>(TEXT("AssetTools"));

		AssetToolsModule.Get().CreateUniqueAssetName(
			TEXT("/Game/TileMapBakes/SM_TileMapTerrain"),
			TEXT(""),
			PackageName,
			AssetName
		);

		UPackage* Package =
			CreatePackage(nullptr, *PackageName);

		if (!Package)
		{
			return nullptr;
		}

		UStaticMesh* StaticMesh =
			NewObject<UStaticMesh>(
				Package,
				FName(*AssetName),
				RF_Public | RF_Standalone
			);

		if (!StaticMesh)
		{
			return nullptr;
		}

		StaticMesh->InitResources();

		FStaticMeshSourceModel& SourceModel =
			StaticMesh->AddSourceModel();

		SourceModel.BuildSettings.bRecomputeNormals = true;
		SourceModel.BuildSettings.bRecomputeTangents = true;
		SourceModel.BuildSettings.bRemoveDegenerates = true;
		SourceModel.BuildSettings.bUseMikkTSpace = true;
		SourceModel.BuildSettings.bGenerateLightmapUVs = true;
		SourceModel.BuildSettings.SrcLightmapIndex = 0;
		SourceModel.BuildSettings.DstLightmapIndex = 1;

		SourceModel.RawMeshBulkData->SaveRawMesh(RawMesh);

		for (UMaterialInterface* Material : Materials)
		{
			StaticMesh->StaticMaterials.Add(
				FStaticMaterial(Material)
			);
		}

		for (
			int32 MaterialIndex = 0;
			MaterialIndex < Materials.Num();
			++MaterialIndex
			)
		{
			FMeshSectionInfo SectionInfo =
				StaticMesh->SectionInfoMap.Get(
					0,
					MaterialIndex
				);

			SectionInfo.MaterialIndex = MaterialIndex;
			SectionInfo.bEnableCollision = true;
			StaticMesh->SectionInfoMap.Set(
				0,
				MaterialIndex,
				SectionInfo
			);
		}

		StaticMesh->LightMapCoordinateIndex = 1;
		StaticMesh->LightMapResolution = 64;
		StaticMesh->CreateBodySetup();

		if (StaticMesh->BodySetup)
		{
			StaticMesh->BodySetup->CollisionTraceFlag =
				CTF_UseComplexAsSimple;
		}

		StaticMesh->Build(false);
		StaticMesh->MarkPackageDirty();
		StaticMesh->PostEditChange();
		Package->MarkPackageDirty();

		FAssetRegistryModule::AssetCreated(StaticMesh);

		UWorld* EditorWorld = TerrainActor->GetWorld();

		if (EditorWorld)
		{
			const FScopedTransaction Transaction(
				LOCTEXT(
					"PlaceBakedTerrainTransaction",
					"Place Baked Tile Map Terrain"
				)
			);

			EditorWorld->Modify();

			ULevel* ActorLevel = TerrainActor->GetLevel();

			if (ActorLevel)
			{
				ActorLevel->Modify();
			}

			FActorSpawnParameters SpawnParameters;
			SpawnParameters.ObjectFlags |= RF_Transactional;
			SpawnParameters.OverrideLevel = ActorLevel;

			AStaticMeshActor* BakedActor =
				EditorWorld->SpawnActor<AStaticMeshActor>(
					TerrainActor->GetActorLocation(),
					TerrainActor->GetActorRotation(),
					SpawnParameters
				);

			if (BakedActor)
			{
				BakedActor->SetActorScale3D(
					TerrainActor->GetActorScale3D()
				);

				BakedActor->SetActorLabel(
					TEXT("TileMap_Terrain_Baked")
				);

				UStaticMeshComponent* BakedComponent =
					BakedActor->GetStaticMeshComponent();

				if (BakedComponent)
				{
					BakedComponent->SetMobility(
						EComponentMobility::Movable
					);

					BakedComponent->SetStaticMesh(StaticMesh);
				}

				if (GEditor)
				{
					GEditor->SelectNone(false, true, false);
					GEditor->SelectActor(
						BakedActor,
						true,
						true,
						true
					);
				}
			}
		}

		if (GEditor)
		{
			TArray<UObject*> ObjectsToSync;
			ObjectsToSync.Add(StaticMesh);
			GEditor->SyncBrowserToObjects(ObjectsToSync);
		}

		return StaticMesh;
	}
}

int32 FTileMapEdModeToolkit::EnsureSlantTile(
	ATileMapTerrainActor* TerrainActor,
	ETileMapSlantMode SlantMode,
	float SlantAngle,
	int32 MaterialTileType,
	int32 RampSegmentIndex,
	int32 RampSegmentCount
)
{
	if (!TerrainActor)
	{
		return INDEX_NONE;
	}

	const float SafeAngle =
		FMath::Clamp(SlantAngle, 5.0f, 45.0f);

	const int32 SafeSegmentCount =
		SlantMode == ETileMapSlantMode::Ramp
		? FMath::Clamp(RampSegmentCount, 1, 8)
		: 1;

	const int32 SafeSegmentIndex =
		SlantMode == ETileMapSlantMode::Ramp
		? FMath::Clamp(
			RampSegmentIndex,
			0,
			SafeSegmentCount - 1
		)
		: 0;

	const float EffectiveAngle =
		SlantMode == ETileMapSlantMode::Ramp
		? FMath::RadiansToDegrees(
			FMath::Atan(1.0f / SafeSegmentCount)
		)
		: SafeAngle;

	const int32 AngleTenths =
		FMath::RoundToInt(EffectiveAngle * 10.0f);

	UMaterialInterface* TileMaterial =
		TerrainActor->GetTileMaterialOverride(MaterialTileType);

	if (!TileMaterial)
	{
		UStaticMesh* MaterialSourceMesh =
			TerrainActor->GetTileMesh(MaterialTileType);

		if (MaterialSourceMesh)
		{
			TileMaterial = MaterialSourceMesh->GetMaterial(0);
		}
	}

	if (!TileMaterial)
	{
		TileMaterial = UMaterial::GetDefaultMaterial(MD_Surface);
	}

	const uint32 MaterialHash =
		GetTypeHash(TileMaterial->GetPathName());
	uint32 DiagonalGeometryHash = 0;

	if (SlantMode == ETileMapSlantMode::DiagonalEdge)
	{
		const float AuthoringScale =
			100.0f / FMath::Max(TerrainActor->GridSize, 1.0f);
		DiagonalGeometryHash = HashCombine(
			GetTypeHash(
				FMath::Clamp(
					TerrainActor->ContinuousChamferSubdivisions,
					2,
					16
				)
			),
			GetTypeHash(
				FMath::RoundToInt(
					TerrainActor->ContinuousChamferWidth *
					AuthoringScale *
					100.0f
				)
			)
		);
		DiagonalGeometryHash = HashCombine(
			DiagonalGeometryHash,
			GetTypeHash(
				FMath::RoundToInt(
					TerrainActor->ContinuousChamferDepth *
					AuthoringScale *
					100.0f
				)
			)
		);
		DiagonalGeometryHash = HashCombine(
			DiagonalGeometryHash,
			GetTypeHash(
				FMath::RoundToInt(
					TerrainActor->ContinuousEdgeIrregularity *
					AuthoringScale *
					100.0f
				)
			)
		);
		DiagonalGeometryHash = HashCombine(
			DiagonalGeometryHash,
			GetTypeHash(
				FMath::RoundToInt(
					TerrainActor->ContinuousEdgeWavelength *
					AuthoringScale *
					100.0f
				)
			)
		);
		DiagonalGeometryHash = HashCombine(
			DiagonalGeometryHash,
			GetTypeHash(
				FMath::RoundToInt(
					TerrainActor->ContinuousCliffCornerRadius *
					AuthoringScale *
					100.0f
				)
			)
		);
	}

	const TCHAR* ShapePrefix =
		SlantMode == ETileMapSlantMode::Ramp
		? TEXT("Ramp")
		: TEXT("DiagonalEdge");

	const FString AssetName =
		SlantMode == ETileMapSlantMode::Ramp
		? FString::Printf(
			TEXT("SM_TileMapV4%s_N%02d_S%02d_A%03d_M%08X"),
			ShapePrefix,
			SafeSegmentCount,
			SafeSegmentIndex,
			AngleTenths,
			MaterialHash
		)
		: FString::Printf(
			TEXT("SM_TileMapV5%s_A%03d_G%08X_M%08X"),
			ShapePrefix,
			AngleTenths,
			DiagonalGeometryHash,
			MaterialHash
		);

	const FName TileName(*AssetName);

	for (int32 PaletteIndex = 0;
		PaletteIndex < TerrainActor->TilePalette.Num();
		++PaletteIndex)
	{
		const FTileMapTileDefinition& ExistingDefinition =
			TerrainActor->TilePalette[PaletteIndex];

		if (
			ExistingDefinition.TileName == TileName &&
			ExistingDefinition.Mesh
			)
		{
			return PaletteIndex + 1;
		}
	}

	const FString PackageName =
		FString::Printf(
			TEXT("/Game/TileMapGenerated/%s"),
			*AssetName
		);

	const FString ObjectPath = FString::Printf(
		TEXT("%s.%s"),
		*PackageName,
		*AssetName
	);

	UStaticMesh* StaticMesh =
		LoadObject<UStaticMesh>(
			nullptr,
			*ObjectPath
		);

	if (!StaticMesh)
	{
		FRawMesh RawMesh;
		const int32 MaterialIndex = 0;

		if (SlantMode == ETileMapSlantMode::Ramp)
		{
			// The complete run occupies the selected cells themselves. It
			// rises from the bottom of the first block to the top of the last
			// block instead of placing another ramp volume above full cubes.
			const float SegmentRise =
				100.0f / SafeSegmentCount;

			const float LowTopZ =
				-50.0f + SafeSegmentIndex * SegmentRise;

			const float HighTopZ =
				LowTopZ + SegmentRise;

			const FVector BottomLowFront(-50.0f, -50.0f, -50.0f);
			const FVector BottomHighFront(50.0f, -50.0f, -50.0f);
			const FVector BottomLowBack(-50.0f, 50.0f, -50.0f);
			const FVector BottomHighBack(50.0f, 50.0f, -50.0f);

			const FVector TopLowFront(-50.0f, -50.0f, LowTopZ);
			const FVector TopHighFront(50.0f, -50.0f, HighTopZ);
			const FVector TopLowBack(-50.0f, 50.0f, LowTopZ);
			const FVector TopHighBack(50.0f, 50.0f, HighTopZ);

			const FVector BottomFace[4] =
			{
				BottomLowBack,
				BottomHighBack,
				BottomHighFront,
				BottomLowFront
			};

			const FVector LowEndFace[4] =
			{
				BottomLowBack,
				BottomLowFront,
				TopLowFront,
				TopLowBack
			};

			const FVector HighEndFace[4] =
			{
				BottomHighFront,
				BottomHighBack,
				TopHighBack,
				TopHighFront
			};

			const FVector FrontFace[4] =
			{
				BottomLowFront,
				BottomHighFront,
				TopHighFront,
				TopLowFront
			};

			const FVector BackFace[4] =
			{
				BottomHighBack,
				BottomLowBack,
				TopLowBack,
				TopHighBack
			};

			const FVector SlopeFace[4] =
			{
				TopLowFront,
				TopHighFront,
				TopHighBack,
				TopLowBack
			};

			const FVector SlopeNormal =
				FVector(-SegmentRise, 0.0f, 100.0f)
				.GetSafeNormal();

			TileMapEdModeToolkitLocal::AddRawMeshFace(
				RawMesh,
				BottomFace,
				-FVector::UpVector,
				MaterialIndex
			);

			if (SafeSegmentIndex > 0)
			{
				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					LowEndFace,
					-FVector::ForwardVector,
					MaterialIndex
				);
			}

			TileMapEdModeToolkitLocal::AddRawMeshFace(
				RawMesh,
				HighEndFace,
				FVector::ForwardVector,
				MaterialIndex
			);

			if (SafeSegmentIndex == 0)
			{
				TileMapEdModeToolkitLocal::AddRawMeshTriangle(
					RawMesh,
					BottomLowFront,
					BottomHighFront,
					TopHighFront,
					-FVector::RightVector,
					MaterialIndex
				);

				TileMapEdModeToolkitLocal::AddRawMeshTriangle(
					RawMesh,
					BottomLowBack,
					TopHighBack,
					BottomHighBack,
					FVector::RightVector,
					MaterialIndex
				);
			}
			else
			{
				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					FrontFace,
					-FVector::RightVector,
					MaterialIndex
				);

				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					BackFace,
					FVector::RightVector,
					MaterialIndex
				);
			}

			TileMapEdModeToolkitLocal::AddRawMeshFace(
				RawMesh,
				SlopeFace,
				SlopeNormal,
				MaterialIndex
			);
		}
		else
		{
			const float DiagonalRise = FMath::Clamp(
				FMath::Tan(FMath::DegreesToRadians(SafeAngle)) * 100.0f,
				1.0f,
				100.0f
			);
			const float CutY = -50.0f + DiagonalRise;
			const float AuthoringScale =
				100.0f / FMath::Max(TerrainActor->GridSize, 1.0f);
			const int32 EdgeSubdivisions = FMath::Clamp(
				TerrainActor->ContinuousChamferSubdivisions,
				2,
				16
			);
			const int32 CornerSubdivisions = FMath::Clamp(
				EdgeSubdivisions / 2,
				2,
				8
			);
			const float TrianglePerimeter =
				100.0f +
				DiagonalRise +
				FMath::Sqrt(
					10000.0f +
					DiagonalRise * DiagonalRise
				);
			const float TriangleInradius =
				100.0f * DiagonalRise /
				FMath::Max(TrianglePerimeter, 1.0f);
			const float ChamferWidth = FMath::Min(
				FMath::Clamp(
					TerrainActor->ContinuousChamferWidth *
					AuthoringScale,
					1.0f,
					30.0f
				),
				FMath::Max(TriangleInradius * 0.7f, 1.0f)
			);
			const float ChamferDepth = FMath::Clamp(
				TerrainActor->ContinuousChamferDepth *
				AuthoringScale,
				1.0f,
				25.0f
			);
			const float CornerRadius = FMath::Clamp(
				TerrainActor->ContinuousCliffCornerRadius *
				AuthoringScale,
				1.0f,
				20.0f
			);
			const float EdgeIrregularity = FMath::Clamp(
				TerrainActor->ContinuousEdgeIrregularity *
				AuthoringScale,
				0.0f,
				FMath::Min(10.0f, ChamferWidth * 0.75f)
			);
			const float EdgeWavelength = FMath::Clamp(
				TerrainActor->ContinuousEdgeWavelength *
				AuthoringScale,
				25.0f,
				200.0f
			);
			const FVector2D Triangle[3] =
			{
				FVector2D(-50.0f, -50.0f),
				FVector2D(50.0f, -50.0f),
				FVector2D(50.0f, CutY)
			};
			const FVector2D TriangleCenter =
				(Triangle[0] + Triangle[1] + Triangle[2]) /
				3.0f;
			TArray<TileMapEdModeToolkitLocal::FDiagonalBoundaryPoint>
				Boundary;

			TileMapEdModeToolkitLocal::BuildDiagonalBoundary(
				Triangle,
				EdgeSubdivisions,
				CornerSubdivisions,
				CornerRadius,
				EdgeIrregularity,
				EdgeWavelength,
				Boundary
			);

			TArray<FVector> FlatTopBoundary;
			TArray<FVector> BottomBoundary;
			FlatTopBoundary.Reserve(Boundary.Num());
			BottomBoundary.Reserve(Boundary.Num());

			for (
				const TileMapEdModeToolkitLocal::FDiagonalBoundaryPoint&
				BoundaryPoint : Boundary
				)
			{
				const FVector2D DirectionToCenter =
					(TriangleCenter - BoundaryPoint.BasePoint)
					.GetSafeNormal();
				const float InsetDistance = FMath::Min(
					ChamferWidth,
					(
						TriangleCenter -
						BoundaryPoint.BasePoint
					).Size() * 0.45f
				);
				const FVector2D FlatTopPoint =
					BoundaryPoint.BasePoint +
					DirectionToCenter * InsetDistance;

				FlatTopBoundary.Add(
					FVector(
						FlatTopPoint.X,
						FlatTopPoint.Y,
						50.0f
					)
				);
				BottomBoundary.Add(
					FVector(
						BoundaryPoint.BasePoint.X,
						BoundaryPoint.BasePoint.Y,
						-50.0f
					)
				);
			}

			TileMapEdModeToolkitLocal::AddRawMeshPolygon(
				RawMesh,
				FlatTopBoundary,
				FVector::UpVector,
				MaterialIndex,
				false
			);
			TileMapEdModeToolkitLocal::AddRawMeshPolygon(
				RawMesh,
				BottomBoundary,
				-FVector::UpVector,
				MaterialIndex,
				true
			);

			const float LipZ = 50.0f - ChamferDepth;
			const float ShoulderZ = FMath::Max(
				-50.0f,
				LipZ - ChamferDepth
			);

			for (int32 BoundaryIndex = 0;
				BoundaryIndex < Boundary.Num();
				++BoundaryIndex)
			{
				const int32 NextBoundaryIndex =
					(BoundaryIndex + 1) % Boundary.Num();
				const TileMapEdModeToolkitLocal::FDiagonalBoundaryPoint&
					PointA = Boundary[BoundaryIndex];
				const TileMapEdModeToolkitLocal::FDiagonalBoundaryPoint&
					PointB = Boundary[NextBoundaryIndex];
				const FVector2D AverageOutwardNormal =
					(
						PointA.OutwardNormal +
						PointB.OutwardNormal
					).GetSafeNormal();
				const FVector WallNormal(
					AverageOutwardNormal.X,
					AverageOutwardNormal.Y,
					0.0f
				);
				const FVector LipNormal = FVector(
					AverageOutwardNormal.X,
					AverageOutwardNormal.Y,
					ChamferWidth /
					FMath::Max(ChamferDepth, 1.0f)
				).GetSafeNormal();
				const FVector TopLipA(
					PointA.WavyPoint.X,
					PointA.WavyPoint.Y,
					LipZ
				);
				const FVector TopLipB(
					PointB.WavyPoint.X,
					PointB.WavyPoint.Y,
					LipZ
				);
				const FVector ShoulderA(
					PointA.BasePoint.X,
					PointA.BasePoint.Y,
					ShoulderZ
				);
				const FVector ShoulderB(
					PointB.BasePoint.X,
					PointB.BasePoint.Y,
					ShoulderZ
				);
				const FVector BottomA(
					PointA.BasePoint.X,
					PointA.BasePoint.Y,
					-50.0f
				);
				const FVector BottomB(
					PointB.BasePoint.X,
					PointB.BasePoint.Y,
					-50.0f
				);
				const FVector TopChamfer[4] =
				{
					TopLipA,
					TopLipB,
					FlatTopBoundary[NextBoundaryIndex],
					FlatTopBoundary[BoundaryIndex]
				};
				const FVector LipTransition[4] =
				{
					ShoulderA,
					ShoulderB,
					TopLipB,
					TopLipA
				};
				const FVector MainWall[4] =
				{
					BottomA,
					BottomB,
					ShoulderB,
					ShoulderA
				};

				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					TopChamfer,
					LipNormal,
					MaterialIndex
				);
				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					LipTransition,
					WallNormal,
					MaterialIndex
				);
				TileMapEdModeToolkitLocal::AddRawMeshFace(
					RawMesh,
					MainWall,
					WallNormal,
					MaterialIndex
				);
			}
		}

		if (!RawMesh.IsValidOrFixable())
		{
			return INDEX_NONE;
		}

		UPackage* Package = CreatePackage(nullptr, *PackageName);

		if (!Package)
		{
			return INDEX_NONE;
		}

		StaticMesh = NewObject<UStaticMesh>(
			Package,
			FName(*AssetName),
			RF_Public | RF_Standalone
		);

		if (!StaticMesh)
		{
			return INDEX_NONE;
		}

		StaticMesh->InitResources();

		FStaticMeshSourceModel& SourceModel =
			StaticMesh->AddSourceModel();

		SourceModel.BuildSettings.bRecomputeNormals = true;
		SourceModel.BuildSettings.bRecomputeTangents = true;
		SourceModel.BuildSettings.bRemoveDegenerates = true;
		SourceModel.BuildSettings.bUseMikkTSpace = true;
		SourceModel.BuildSettings.bGenerateLightmapUVs = true;
		SourceModel.BuildSettings.SrcLightmapIndex = 0;
		SourceModel.BuildSettings.DstLightmapIndex = 1;
		SourceModel.RawMeshBulkData->SaveRawMesh(RawMesh);

		StaticMesh->StaticMaterials.Add(FStaticMaterial(TileMaterial));
		StaticMesh->LightMapCoordinateIndex = 1;
		StaticMesh->LightMapResolution = 64;
		StaticMesh->CreateBodySetup();

		if (StaticMesh->BodySetup)
		{
			StaticMesh->BodySetup->CollisionTraceFlag =
				CTF_UseComplexAsSimple;
		}

		StaticMesh->Build(false);
		StaticMesh->MarkPackageDirty();
		StaticMesh->PostEditChange();
		Package->MarkPackageDirty();
		FAssetRegistryModule::AssetCreated(StaticMesh);
	}

	FTileMapTileDefinition NewDefinition;
	NewDefinition.TileName = TileName;
	NewDefinition.Mesh = StaticMesh;
	NewDefinition.MaterialOverride = TileMaterial;
	NewDefinition.AutoShape =
		SlantMode == ETileMapSlantMode::Ramp
		? ETileMapAutoShape::Ramp
		: ETileMapAutoShape::DiagonalEdge;

	const int32 NewPaletteIndex =
		TerrainActor->TilePalette.Add(NewDefinition);

	return NewPaletteIndex + 1;
}

void FTileMapEdModeToolkit::Init(
	const TSharedPtr<IToolkitHost>& InitToolkitHost
)
{
	const auto MakeToolCheckBox =
		[this](
			ETileMapCursorTool Tool,
			const FText& Label
			) -> TSharedRef<SWidget>
		{
			return
				SNew(SCheckBox)
				.IsChecked_Lambda(
					[this, Tool]()
					{
						FTileMapEdMode* TileMapMode =
							static_cast<
							FTileMapEdMode*
							>(
								GetEditorMode()
								);

						if (
							TileMapMode &&
							TileMapMode
							->GetActiveTool() ==
							Tool
							)
						{
							return
								ECheckBoxState::Checked;
						}

						return
							ECheckBoxState::Unchecked;
					}
				)
				.OnCheckStateChanged_Lambda(
					[this, Tool](
						ECheckBoxState NewState
						)
					{
						FTileMapEdMode* TileMapMode =
							static_cast<
							FTileMapEdMode*
							>(
								GetEditorMode()
								);

						if (!TileMapMode)
						{
							return;
						}

						TileMapMode->SetActiveTool(
							NewState ==
							ECheckBoxState::Checked
							? Tool
							: ETileMapCursorTool::
							None
						);
					}
				)
				[
					SNew(STextBlock)
						.Text(Label)
				];
		};

	const auto MakeSlantModeCheckBox =
		[this](
			ETileMapSlantMode SlantMode,
			const FText& Label
			) -> TSharedRef<SWidget>
		{
			return
				SNew(SCheckBox)
				.IsChecked_Lambda(
					[this, SlantMode]()
					{
						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						return
							TileMapMode &&
							TileMapMode->GetSlantMode() == SlantMode
							? ECheckBoxState::Checked
							: ECheckBoxState::Unchecked;
					}
				)
				.OnCheckStateChanged_Lambda(
					[this, SlantMode](ECheckBoxState NewState)
					{
						if (NewState != ECheckBoxState::Checked)
						{
							return;
						}

						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						if (TileMapMode)
						{
							TileMapMode->SetSlantMode(SlantMode);
						}
					}
				)
				[
					SNew(STextBlock)
					.Text(Label)
				];
		};

	const auto MakeSlantDirectionCheckBox =
		[this](
			ETileMapSlantDirection Direction,
			const FText& Label
			) -> TSharedRef<SWidget>
		{
			return
				SNew(SCheckBox)
				.IsChecked_Lambda(
					[this, Direction]()
					{
						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						return
							TileMapMode &&
							TileMapMode->GetSlantDirection() == Direction
							? ECheckBoxState::Checked
							: ECheckBoxState::Unchecked;
					}
				)
				.OnCheckStateChanged_Lambda(
					[this, Direction](ECheckBoxState NewState)
					{
						if (NewState != ECheckBoxState::Checked)
						{
							return;
						}

						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						if (TileMapMode)
						{
							TileMapMode->SetSlantDirection(Direction);
						}
					}
				)
				[
					SNew(STextBlock)
					.Text(Label)
				];
		};

	InlineWidget =
		SNew(SVerticalBox)

		// TITLE
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f)
		[
			SNew(STextBlock)
				.Text(
					LOCTEXT(
						"TerrainEditorTitle",
						"Reditus Terrain Editor"
					)
				)
		]

	// ACTIVE TILE LABEL
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			SNew(STextBlock)
				.AutoWrapText(true)
				.Text_Lambda([this]()
					{
						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						const int32 TileType =
							TileMapMode
							? TileMapMode->GetActiveTileType()
							: 0;

						ATileMapTerrainActor* TerrainActor =
							nullptr;

						if (GEditor)
						{
							TerrainActor =
								TileMapEdModeToolkitLocal::
								FindTerrainActor(
									GEditor
									->GetEditorWorldContext()
									.World()
								);
						}

						const FText TileName =
							TerrainActor
							? TerrainActor->GetTileDisplayName(
								TileType
							)
							: LOCTEXT(
								"DefaultTileName",
								"Default Block"
							);

						return FText::FromString(
							FString::Printf(
								TEXT("Active Tile %d: %s"),
								TileType,
								*TileName.ToString()
							)
						);
					})
		]

	// ACTIVE TILE NUMBER
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 0.0f, 10.0f, 5.0f)
		[
			SNew(SSpinBox<int32>)
				.MinValue(0)
				.MaxValue(255)
				.MinSliderValue(0)
				.MaxSliderValue(32)
				.Value_Lambda([this]()
					{
						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						return TileMapMode
							? TileMapMode->GetActiveTileType()
							: 0;
					})
				.OnValueChanged_Lambda(
					[this](int32 NewTileType)
					{
						FTileMapEdMode* TileMapMode =
							static_cast<FTileMapEdMode*>(
								GetEditorMode()
							);

						if (!TileMapMode)
						{
							return;
						}

						int32 SafeTileType =
							FMath::Max(NewTileType, 0);

						if (GEditor)
						{
							ATileMapTerrainActor* TerrainActor =
								TileMapEdModeToolkitLocal::
								FindTerrainActor(
									GEditor
									->GetEditorWorldContext()
									.World()
								);

							if (TerrainActor)
							{
								SafeTileType = FMath::Clamp(
									SafeTileType,
									0,
									TerrainActor
									->GetTileTypeCount() - 1
								);
							}
						}

						TileMapMode->SetActiveTileType(
							SafeTileType
						);
					}
				)
		]

	// CREATE TEST GRID
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f)
		[
			SNew(SButton)
				.Text(
					LOCTEXT(
						"CreateGridButton",
						"Create Test Grid"
					)
				)
				.OnClicked_Lambda([]()
					{
						if (!GEditor)
						{
							FMessageDialog::Open(
								EAppMsgType::Ok,
								LOCTEXT(
									"NoEditorMessage",
									"Could not access the Unreal Editor."
								)
							);

							return FReply::Handled();
						}

						UWorld* EditorWorld =
							GEditor
							->GetEditorWorldContext()
							.World();

						if (!EditorWorld)
						{
							FMessageDialog::Open(
								EAppMsgType::Ok,
								LOCTEXT(
									"NoWorldMessage",
									"Could not find the current editor world."
								)
							);

							return FReply::Handled();
						}

						const FScopedTransaction
							Transaction(
								LOCTEXT(
									"CreateTerrainTransaction",
									"Create Tile Map Terrain"
								)
							);

						ATileMapTerrainActor*
							TerrainActor =
							nullptr;

						// Reuse the current terrain actor.
						for (
							TActorIterator<
							ATileMapTerrainActor
							> It(EditorWorld);
							It;
							++It
							)
						{
							TerrainActor = *It;
							break;
						}

						if (!TerrainActor)
						{
							EditorWorld->Modify();

							ULevel* CurrentLevel =
								EditorWorld
								->GetCurrentLevel();

							if (CurrentLevel)
							{
								CurrentLevel->Modify();
							}

							FActorSpawnParameters
								SpawnParameters;

							SpawnParameters
								.SpawnCollisionHandlingOverride =
								ESpawnActorCollisionHandlingMethod::
								AlwaysSpawn;

							SpawnParameters.ObjectFlags |=
								RF_Transactional;

							SpawnParameters.OverrideLevel =
								CurrentLevel;

							TerrainActor =
								EditorWorld->SpawnActor<
								ATileMapTerrainActor
								>(
									FVector::ZeroVector,
									FRotator::ZeroRotator,
									SpawnParameters
								);

							if (!TerrainActor)
							{
								FMessageDialog::Open(
									EAppMsgType::Ok,
									LOCTEXT(
										"TerrainSpawnFailure",
										"Could not create the tile map terrain actor."
									)
								);

								return
									FReply::Handled();
							}

							TerrainActor->SetActorLabel(
								TEXT(
									"TileMap_Terrain"
								)
							);
						}

						TerrainActor->Modify();

						TerrainActor->CreateTestGrid(
							10,
							10
						);

						GEditor->SelectNone(
							false,
							true,
							false
						);

						GEditor->SelectActor(
							TerrainActor,
							true,
							true,
							true
						);

						return FReply::Handled();
					})
		]

	// SEPARATOR
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			SNew(SSeparator)
		]

		// CURSOR TOOLS TITLE
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f)
		[
			SNew(STextBlock)
				.Text(
					LOCTEXT(
						"CursorToolsTitle",
						"Cursor Tools"
					)
				)
		]

	// ADD / STACK
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::AddBlock,
				LOCTEXT(
					"AddBlockTool",
					"Add / Stack Block"
				)
			)
		]

	// PAINT / REPLACE TILE TYPE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::PaintTile,
				LOCTEXT(
					"PaintTileTool",
					"Paint / Replace Tile"
				)
			)
		]

	// ROTATE TILE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::RotateTile,
				LOCTEXT(
					"RotateTileTool",
					"Rotate Tile 90 Degrees"
				)
			)
		]

	// SLANT SETTINGS TITLE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 8.0f, 10.0f, 3.0f)
		[
			SNew(STextBlock)
			.Text(
				LOCTEXT(
					"SlantSettingsTitle",
					"Slant Shape"
				)
			)
		]

	// RAMP MODE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 3.0f)
		[
			MakeSlantModeCheckBox(
				ETileMapSlantMode::Ramp,
				LOCTEXT(
					"RampSlantMode",
					"Ramp (vertical rise)"
				)
			)
		]

	// DIAGONAL EDGE MODE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 3.0f)
		[
			MakeSlantModeCheckBox(
				ETileMapSlantMode::DiagonalEdge,
				LOCTEXT(
					"DiagonalEdgeSlantMode",
					"Diagonal Edge (horizontal cut)"
				)
			)
		]

	// SLANT ANGLE LABEL
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 6.0f, 10.0f, 2.0f)
		[
			SNew(STextBlock)
			.Text(
				LOCTEXT(
					"SlantAngleLabel",
					"Slant Angle (5-45 degrees)"
				)
			)
		]

	// SLANT DIRECTION LABEL
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 6.0f, 10.0f, 2.0f)
		[
			SNew(STextBlock)
			.Text(
				LOCTEXT(
					"SlantDirectionLabel",
					"Rise / cut direction"
				)
			)
		]

	// SLANT DIRECTION BUTTONS
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 0.0f, 10.0f, 5.0f)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0.0f, 0.0f, 8.0f, 0.0f)
			[
				MakeSlantDirectionCheckBox(
					ETileMapSlantDirection::PositiveX,
					LOCTEXT("SlantPositiveX", "+X")
				)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0.0f, 0.0f, 8.0f, 0.0f)
			[
				MakeSlantDirectionCheckBox(
					ETileMapSlantDirection::PositiveY,
					LOCTEXT("SlantPositiveY", "+Y")
				)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0.0f, 0.0f, 8.0f, 0.0f)
			[
				MakeSlantDirectionCheckBox(
					ETileMapSlantDirection::NegativeX,
					LOCTEXT("SlantNegativeX", "-X")
				)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				MakeSlantDirectionCheckBox(
					ETileMapSlantDirection::NegativeY,
					LOCTEXT("SlantNegativeY", "-Y")
				)
			]
		]

	// SLANT ANGLE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 0.0f, 10.0f, 5.0f)
		[
			SNew(SSpinBox<float>)
			.MinValue(5.0f)
			.MaxValue(45.0f)
			.MinSliderValue(5.0f)
			.MaxSliderValue(45.0f)
			.Delta(1.0f)
			.Value_Lambda([this]()
				{
					FTileMapEdMode* TileMapMode =
						static_cast<FTileMapEdMode*>(
							GetEditorMode()
						);

					return TileMapMode
						? TileMapMode->GetSlantAngle()
						: 26.565f;
				})
			.OnValueChanged_Lambda(
				[this](float NewAngle)
				{
					FTileMapEdMode* TileMapMode =
						static_cast<FTileMapEdMode*>(
							GetEditorMode()
						);

					if (TileMapMode)
					{
						TileMapMode->SetSlantAngle(NewAngle);
					}
				}
			)
		]

	// EFFECTIVE GRID-COMPATIBLE RAMP
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 0.0f, 10.0f, 5.0f)
		[
			SNew(STextBlock)
			.AutoWrapText(true)
			.Text_Lambda([this]()
				{
					FTileMapEdMode* TileMapMode =
						static_cast<FTileMapEdMode*>(
							GetEditorMode()
						);

					if (!TileMapMode)
					{
						return FText::GetEmpty();
					}

					return FText::FromString(
						FString::Printf(
							TEXT("Continuous ramp: %d tile(s), actual %.1f degrees"),
							TileMapMode->GetRampSegmentCount(),
							TileMapMode->GetEffectiveRampAngle()
						)
					);
				})
		]

	// APPLY SLANT
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::SetSlant,
				LOCTEXT(
					"SetSlantTool",
					"Apply Slant"
				)
			)
		]

	// RAISE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::RaiseBlock,
				LOCTEXT(
					"RaiseBlockTool",
					"Raise Block"
				)
			)
		]

	// LOWER
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::LowerBlock,
				LOCTEXT(
					"LowerBlockTool",
					"Lower Block"
				)
			)
		]

	// DELETE
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			MakeToolCheckBox(
				ETileMapCursorTool::DeleteBlock,
				LOCTEXT(
					"DeleteBlockTool",
					"Delete Block"
				)
			)
		]

	// SEPARATOR
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			SNew(SSeparator)
		]

	// BAKE STATIC MESH
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f, 5.0f)
		[
			SNew(SButton)
				.Text(
					LOCTEXT(
						"BakeStaticMeshButton",
						"Bake Optimized Static Mesh"
					)
				)
				.OnClicked_Lambda([]()
					{
						if (!GEditor)
						{
							return FReply::Handled();
						}

						UWorld* EditorWorld =
							GEditor
							->GetEditorWorldContext()
							.World();

						ATileMapTerrainActor* TerrainActor =
							TileMapEdModeToolkitLocal::
							FindTerrainActor(EditorWorld);

						if (!TerrainActor)
						{
							FMessageDialog::Open(
								EAppMsgType::Ok,
								LOCTEXT(
									"NoTerrainToBake",
									"Create or select a tile map terrain actor first."
								)
							);

							return FReply::Handled();
						}

						UStaticMesh* BakedMesh =
							TileMapEdModeToolkitLocal::
							BakeTerrainToStaticMesh(
								TerrainActor
							);

						FMessageDialog::Open(
							EAppMsgType::Ok,
							BakedMesh
							? LOCTEXT(
								"BakeSucceeded",
								"The optimized mesh was created in /Game/TileMapBakes and a movable baked actor was placed in the level. Use Save All, then export the mesh asset from the Content Browser when needed."
							)
							: LOCTEXT(
								"BakeFailed",
								"The terrain could not be baked. Make sure it contains blocks and every palette mesh has valid LOD 0 source geometry."
							)
						);

						return FReply::Handled();
					})
		]

	// HELP
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10.0f)
		[
			SNew(STextBlock)
				.AutoWrapText(true)
				.Text(
					LOCTEXT(
						"CursorToolHelp",
						"Select the terrain actor and add modular meshes under Details > Tile Map > Palette. Entries sharing an Auto Tile Set automatically choose flat, edge, corner, cliff, pass, and rotation variants from nearby elevation. A ramp converts the displayed run into connected wedges inside the selected cells. Diagonal Edge removes only the nearest cut-side neighbor and its upper stack; it never continues across the map. Vertical Ramp does not delete neighbors. Paint restores another tile and Delete removes it. Every mouse stroke is one Undo/Redo history step."
					)
				)
		];

	FModeToolkit::Init(InitToolkitHost);
}

FName FTileMapEdModeToolkit::GetToolkitFName() const
{
	return FName(TEXT("TileMapEdMode"));
}

FText FTileMapEdModeToolkit::GetBaseToolkitName() const
{
	return LOCTEXT(
		"ToolkitName",
		"Tile Map"
	);
}

FEdMode* FTileMapEdModeToolkit::GetEditorMode() const
{
	return GLevelEditorModeTools().GetActiveMode(
		FTileMapEdMode::EM_TileMapEdModeId
	);
}

TSharedPtr<SWidget>
FTileMapEdModeToolkit::GetInlineContent() const
{
	return InlineWidget;
}

#undef LOCTEXT_NAMESPACE
