TileMapEditor v1.2.68 - Cliff edge beside vertical ramps

Baseline
--------
This revision is a focused update from v1.2.67. The accepted horizontal-cut
support fix, slant hover preview, stacked-ramp continuity, hybrid
continuous/modular baking, collision, path masks, cliff-base blending, and
existing continuous geometry remain in place.

Fix
---
When a continuous Vertical Ramp runs beside an ordinary continuous block, the
ramp generator owns the height-difference wall between the natural slope and
the neighboring flat top. That closure wall was present, but it was emitted
entirely with the main cliff-wall surface. Unlike every exposed cliff wall, it
never generated the dedicated cliff-edge band at its top, leaving the visible
edge unblended beside the ramp.

v1.2.68 now:

* splits only the ramp NeighborWall closure at Chamfer Depth;
* preserves the natural ramp edge and the neighboring block's exact flat top;
* assigns the upper strip the same cliff-top UVs and vertex-color ownership as
  other continuous cliff edges;
* tapers both the wall and cliff-edge strip to one genuine triangle where the
  ramp reaches the flat top, avoiding a zero-area endpoint quad;
* applies the same topology in +X, -X, +Y, and -Y and in optimized static-mesh
  baking because the correction is in the shared continuous generator.

The change does not wave, round, or lift the neighboring cube, and it does not
alter exposed ramp walls, stacked-ramp joins, horizontal diagonal cuts, stairs,
or modular/HISM fallback geometry.

UE4.27 test
-----------
1. Replace the previous TileMapEditor plugin source with this folder.
2. Delete the project's plugin Intermediate/Binaries only if Unreal requests a
   rebuild, then rebuild the UE4.27 editor target.
3. Place a one-cell 45-degree Vertical Ramp beside a normal continuous block.
4. Inspect both long sides from the low foot to the high endpoint. Confirm the
   height-difference wall has a cliff-edge band and closes without a hole.
5. Repeat with the two-cell 26.565-degree ramp and rotate through +X, -X, +Y,
   and -Y.
6. Confirm the band tapers away at the exact high flat join and that separately
   stacked compatible ramps remain one uninterrupted slope.
7. Bake an optimized static mesh and confirm the same edge ownership remains.
