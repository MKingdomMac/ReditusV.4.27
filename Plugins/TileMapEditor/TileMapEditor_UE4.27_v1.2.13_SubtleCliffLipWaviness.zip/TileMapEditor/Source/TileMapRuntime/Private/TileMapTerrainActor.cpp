// Copyright Epic Games, Inc. All Rights Reserved.

#include "TileMapTerrainActor.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/SceneComponent.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"
#include "ProceduralMeshComponent.h"
#include "UObject/ConstructorHelpers.h"

namespace
{
	struct FTileMapContinuousSection
	{
		TArray<FVector> Vertices;
		TArray<int32> Triangles;
		TArray<FVector> Normals;
		TArray<FVector2D> UV0;
		TArray<FColor> VertexColors;
		TArray<FProcMeshTangent> Tangents;
	};

	FVector2D MakeContinuousUV(
		const FVector& Position,
		const FVector& Normal,
		float GridSize
	)
	{
		const float SafeGridSize = FMath::Max(GridSize, 1.0f);
		const FVector AbsoluteNormal = Normal.GetAbs();

		if (AbsoluteNormal.Z >= AbsoluteNormal.X &&
			AbsoluteNormal.Z >= AbsoluteNormal.Y)
		{
			return FVector2D(
				Position.X / SafeGridSize,
				Position.Y / SafeGridSize
			);
		}

		if (AbsoluteNormal.X >= AbsoluteNormal.Y)
		{
			return FVector2D(
				Position.Y / SafeGridSize,
				Position.Z / SafeGridSize
			);
		}

		return FVector2D(
			Position.X / SafeGridSize,
			Position.Z / SafeGridSize
		);
	}

	FVector MakeContinuousTangent(
		const FVector& Normal
	)
	{
		return FMath::Abs(Normal.Z) >= 0.5f
			? FVector::ForwardVector
			: (
				FMath::Abs(Normal.X) >= 0.5f
				? FVector::RightVector
				: FVector::ForwardVector
			);
	}

	int32 AddContinuousVertex(
		FTileMapContinuousSection& Section,
		const FVector& Position,
		const FVector& Normal,
		float GridSize
	)
	{
		const int32 VertexIndex = Section.Vertices.Add(Position);
		Section.Normals.Add(Normal);
		Section.UV0.Add(
			MakeContinuousUV(Position, Normal, GridSize)
		);
		Section.VertexColors.Add(FColor::White);
		Section.Tangents.Add(
			FProcMeshTangent(
				MakeContinuousTangent(Normal),
				false
			)
		);
		return VertexIndex;
	}

	void AddContinuousPolygon(
		FTileMapContinuousSection& Section,
		const TArray<FVector>& Boundary,
		const FVector& Normal,
		float GridSize,
		bool bReverseWinding
	)
	{
		if (Boundary.Num() < 3)
		{
			return;
		}

		FVector Center = FVector::ZeroVector;

		for (const FVector& Point : Boundary)
		{
			Center += Point;
		}

		Center /= static_cast<float>(Boundary.Num());

		const int32 CenterIndex =
			AddContinuousVertex(
				Section,
				Center,
				Normal,
				GridSize
			);

		TArray<int32> BoundaryIndices;
		BoundaryIndices.Reserve(Boundary.Num());

		for (const FVector& Point : Boundary)
		{
			BoundaryIndices.Add(
				AddContinuousVertex(
					Section,
					Point,
					Normal,
					GridSize
				)
			);
		}

		for (int32 Index = 0; Index < BoundaryIndices.Num(); ++Index)
		{
			const int32 NextIndex =
				(Index + 1) % BoundaryIndices.Num();

			Section.Triangles.Add(CenterIndex);

			if (bReverseWinding)
			{
				Section.Triangles.Add(BoundaryIndices[Index]);
				Section.Triangles.Add(BoundaryIndices[NextIndex]);
			}
			else
			{
				Section.Triangles.Add(BoundaryIndices[NextIndex]);
				Section.Triangles.Add(BoundaryIndices[Index]);
			}
		}
	}

	void AddContinuousWallQuad(
		FTileMapContinuousSection& Section,
		const FVector& BottomA,
		const FVector& BottomB,
		const FVector& TopB,
		const FVector& TopA,
		const FVector& NormalA,
		const FVector& NormalB,
		float GridSize
	)
	{
		const int32 A = AddContinuousVertex(
			Section, BottomA, NormalA, GridSize);
		const int32 B = AddContinuousVertex(
			Section, BottomB, NormalB, GridSize);
		const int32 C = AddContinuousVertex(
			Section, TopB, NormalB, GridSize);
		const int32 D = AddContinuousVertex(
			Section, TopA, NormalA, GridSize);
		const FVector DesiredNormal =
			(NormalA + NormalB).GetSafeNormal();

		const FVector WindingNormal =
			FVector::CrossProduct(
				BottomB - BottomA,
				TopB - BottomA
			);

		if (FVector::DotProduct(WindingNormal, DesiredNormal) >= 0.0f)
		{
			Section.Triangles.Add(A);
			Section.Triangles.Add(C);
			Section.Triangles.Add(B);
			Section.Triangles.Add(A);
			Section.Triangles.Add(D);
			Section.Triangles.Add(C);
		}
		else
		{
			Section.Triangles.Add(A);
			Section.Triangles.Add(C);
			Section.Triangles.Add(D);
			Section.Triangles.Add(A);
			Section.Triangles.Add(B);
			Section.Triangles.Add(C);
		}
	}

	void AddContinuousTriangle(
		FTileMapContinuousSection& Section,
		const FVector& PositionA,
		const FVector& PositionB,
		const FVector& PositionC,
		const FVector& NormalA,
		const FVector& NormalB,
		const FVector& NormalC,
		const FVector& DesiredNormal,
		float GridSize
	)
	{
		const int32 A = AddContinuousVertex(
			Section, PositionA, NormalA, GridSize);
		const int32 B = AddContinuousVertex(
			Section, PositionB, NormalB, GridSize);
		const int32 C = AddContinuousVertex(
			Section, PositionC, NormalC, GridSize);
		const FVector WindingNormal =
			FVector::CrossProduct(
				PositionB - PositionA,
				PositionC - PositionA
			);

		Section.Triangles.Add(A);

		// Match the original v1.2.6 RawMesh 0,2,1 front-face convention.
		if (FVector::DotProduct(WindingNormal, DesiredNormal) >= 0.0f)
		{
			Section.Triangles.Add(C);
			Section.Triangles.Add(B);
		}
		else
		{
			Section.Triangles.Add(B);
			Section.Triangles.Add(C);
		}
	}
}

ATileMapTerrainActor::ATileMapTerrainActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(
		TEXT("SceneRoot")
	);

	SceneRoot->SetMobility(EComponentMobility::Movable);
	SetRootComponent(SceneRoot);

	GridSize = 100.0f;
	ChunkSize = 16;
	bGenerateCollision = true;
	DefaultTerrainMaterial = nullptr;
	bUseContinuousTerrainPrototype = false;
	ContinuousChamferSubdivisions = 8;
	ContinuousChamferWidth = 10.0f;
	ContinuousChamferDepth = 5.0f;
	ContinuousEdgeIrregularity = 4.0f;
	ContinuousEdgeWavelength = 65.0f;
	ContinuousCliffCornerRadius = 10.0f;

	static ConstructorHelpers::FObjectFinder<UStaticMesh>
		DefaultCubeMesh(
			TEXT("/Engine/BasicShapes/Cube.Cube")
		);

	if (DefaultCubeMesh.Succeeded())
	{
		BlockMesh = DefaultCubeMesh.Object;
	}
}

void ATileMapTerrainActor::OnConstruction(
	const FTransform& Transform
)
{
	Super::OnConstruction(Transform);
	RebuildAllChunks();
}

#if WITH_EDITOR

void ATileMapTerrainActor::PostEditUndo()
{
	Super::PostEditUndo();

	// The serialized block arrays are the transactional source of truth.
	// HISM components, collision, and lookup tables are derived caches.
	RebuildAllChunks();
}

void ATileMapTerrainActor::PostEditChangeProperty(
	FPropertyChangedEvent& PropertyChangedEvent
)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	RebuildAllChunks();
}

#endif

int32 ATileMapTerrainActor::FloorDivide(
	int32 Value,
	int32 Divisor
)
{
	if (Divisor <= 0)
	{
		return 0;
	}

	int32 Quotient = Value / Divisor;
	const int32 Remainder = Value % Divisor;

	if (Remainder < 0)
	{
		--Quotient;
	}

	return Quotient;
}

FIntVector ATileMapTerrainActor::GetChunkCoordinate(
	const FIntVector& GridPosition
) const
{
	const int32 SafeChunkSize =
		FMath::Max(ChunkSize, 1);

	return FIntVector(
		FloorDivide(GridPosition.X, SafeChunkSize),
		FloorDivide(GridPosition.Y, SafeChunkSize),
		FloorDivide(GridPosition.Z, SafeChunkSize)
	);
}

FVector ATileMapTerrainActor::GridToLocal(
	const FIntVector& GridPosition
) const
{
	const float SafeGridSize =
		FMath::Max(GridSize, 1.0f);

	return FVector(
		(GridPosition.X + 0.5f) * SafeGridSize,
		(GridPosition.Y + 0.5f) * SafeGridSize,
		(GridPosition.Z + 0.5f) * SafeGridSize
	);
}

FVector ATileMapTerrainActor::GridToWorld(
	const FIntVector& GridPosition
) const
{
	return GetActorTransform().TransformPosition(
		GridToLocal(GridPosition)
	);
}

FIntVector ATileMapTerrainActor::WorldToGrid(
	const FVector& WorldPosition
) const
{
	const float SafeGridSize =
		FMath::Max(GridSize, 1.0f);

	const FVector LocalPosition =
		GetActorTransform().InverseTransformPosition(
			WorldPosition
		);

	return FIntVector(
		FMath::FloorToInt(LocalPosition.X / SafeGridSize),
		FMath::FloorToInt(LocalPosition.Y / SafeGridSize),
		FMath::FloorToInt(LocalPosition.Z / SafeGridSize)
	);
}

int32 ATileMapTerrainActor::FindBlockIndex(
	const FIntVector& GridPosition
) const
{
	const int32* FoundIndex =
		BlockIndexLookup.Find(GridPosition);

	return FoundIndex ? *FoundIndex : INDEX_NONE;
}

bool ATileMapTerrainActor::HasBlock(
	const FIntVector& GridPosition
) const
{
	return OccupancyLookup.Contains(GridPosition);
}

int32 ATileMapTerrainActor::GetTileTypeCount() const
{
	// Type 0 is always the backward-compatible BlockMesh.
	return TilePalette.Num() + 1;
}

int32 ATileMapTerrainActor::ClampTileType(
	int32 TileType
) const
{
	return FMath::Clamp(
		TileType,
		0,
		FMath::Max(GetTileTypeCount() - 1, 0)
	);
}

const FTileMapTileDefinition*
ATileMapTerrainActor::GetTileDefinition(
	int32 TileType
) const
{
	const int32 PaletteIndex = TileType - 1;

	return TilePalette.IsValidIndex(PaletteIndex)
		? &TilePalette[PaletteIndex]
		: nullptr;
}

int32 ATileMapTerrainActor::FindAutoTileVariant(
	FName AutoTileSet,
	ETileMapAutoShape AutoShape
) const
{
	if (AutoTileSet.IsNone())
	{
		return INDEX_NONE;
	}

	for (int32 PaletteIndex = 0;
		PaletteIndex < TilePalette.Num();
		++PaletteIndex)
	{
		const FTileMapTileDefinition& Definition =
			TilePalette[PaletteIndex];

		if (
			Definition.AutoTileSet == AutoTileSet &&
			Definition.AutoShape == AutoShape &&
			Definition.Mesh
			)
		{
			return PaletteIndex + 1;
		}
	}

	return INDEX_NONE;
}

ETileMapAutoShape ATileMapTerrainActor::DetermineAutoShape(
	const FIntVector& GridPosition,
	uint8& OutQuarterTurns
) const
{
	OutQuarterTurns = 0;

	static const FIntVector CardinalOffsets[4] =
	{
		FIntVector(1, 0, 0),
		FIntVector(0, 1, 0),
		FIntVector(-1, 0, 0),
		FIntVector(0, -1, 0)
	};

	bool bOpen[4] = { false, false, false, false };
	int32 OpenCount = 0;

	for (int32 DirectionIndex = 0;
		DirectionIndex < 4;
		++DirectionIndex)
	{
		bOpen[DirectionIndex] =
			!HasBlock(
				GridPosition + CardinalOffsets[DirectionIndex]
			);

		OpenCount += bOpen[DirectionIndex] ? 1 : 0;
	}

	const bool bHasBlockAbove =
		HasBlock(GridPosition + FIntVector(0, 0, 1));

	if (bHasBlockAbove)
	{
		if (OpenCount == 0)
		{
			return ETileMapAutoShape::Flat;
		}

		for (int32 DirectionIndex = 0;
			DirectionIndex < 4;
			++DirectionIndex)
		{
			if (bOpen[DirectionIndex])
			{
				OutQuarterTurns =
					static_cast<uint8>(DirectionIndex);
				break;
			}
		}

		return ETileMapAutoShape::Cliff;
	}

	if (OpenCount == 0)
	{
		static const FIntVector DiagonalOffsets[4] =
		{
			FIntVector(1, 1, 0),
			FIntVector(-1, 1, 0),
			FIntVector(-1, -1, 0),
			FIntVector(1, -1, 0)
		};

		for (int32 CornerIndex = 0;
			CornerIndex < 4;
			++CornerIndex)
		{
			if (!HasBlock(GridPosition + DiagonalOffsets[CornerIndex]))
			{
				OutQuarterTurns =
					static_cast<uint8>(CornerIndex);
				return ETileMapAutoShape::InnerCorner;
			}
		}

		return ETileMapAutoShape::Flat;
	}

	if (OpenCount == 1)
	{
		for (int32 DirectionIndex = 0;
			DirectionIndex < 4;
			++DirectionIndex)
		{
			if (bOpen[DirectionIndex])
			{
				OutQuarterTurns =
					static_cast<uint8>(DirectionIndex);
				break;
			}
		}

		return ETileMapAutoShape::Edge;
	}

	if (OpenCount == 2)
	{
		if (bOpen[0] && bOpen[2])
		{
			OutQuarterTurns = 0;
			return ETileMapAutoShape::Pass;
		}

		if (bOpen[1] && bOpen[3])
		{
			OutQuarterTurns = 1;
			return ETileMapAutoShape::Pass;
		}

		if (bOpen[0] && bOpen[1])
		{
			OutQuarterTurns = 0;
		}
		else if (bOpen[1] && bOpen[2])
		{
			OutQuarterTurns = 1;
		}
		else if (bOpen[2] && bOpen[3])
		{
			OutQuarterTurns = 2;
		}
		else
		{
			OutQuarterTurns = 3;
		}

		return ETileMapAutoShape::OuterCorner;
	}

	if (OpenCount == 3)
	{
		for (int32 DirectionIndex = 0;
			DirectionIndex < 4;
			++DirectionIndex)
		{
			if (!bOpen[DirectionIndex])
			{
				OutQuarterTurns =
					static_cast<uint8>((DirectionIndex + 1) % 4);
				break;
			}
		}

		return ETileMapAutoShape::Peninsula;
	}

	return ETileMapAutoShape::Island;
}

bool ATileMapTerrainActor::ResolveAutoTileAt(
	const FIntVector& GridPosition,
	TSet<FIntVector>& OutChangedPositions
)
{
	const int32 BlockIndex = FindBlockIndex(GridPosition);

	if (
		!BlockTileTypes.IsValidIndex(BlockIndex) ||
		!BlockRotations.IsValidIndex(BlockIndex)
		)
	{
		return false;
	}

	const int32 CurrentTileType =
		ClampTileType(BlockTileTypes[BlockIndex]);

	const FTileMapTileDefinition* CurrentDefinition =
		GetTileDefinition(CurrentTileType);

	if (
		!CurrentDefinition ||
		CurrentDefinition->AutoTileSet.IsNone() ||
		CurrentDefinition->AutoShape == ETileMapAutoShape::Ramp ||
		CurrentDefinition->AutoShape == ETileMapAutoShape::DiagonalEdge
		)
	{
		return false;
	}

	uint8 ResolvedRotation = 0;
	const ETileMapAutoShape ResolvedShape =
		DetermineAutoShape(
			GridPosition,
			ResolvedRotation
		);

	int32 ResolvedTileType =
		FindAutoTileVariant(
			CurrentDefinition->AutoTileSet,
			ResolvedShape
		);

	if (ResolvedTileType == INDEX_NONE)
	{
		ResolvedTileType =
			FindAutoTileVariant(
				CurrentDefinition->AutoTileSet,
				ETileMapAutoShape::Manual
			);
	}

	if (ResolvedTileType == INDEX_NONE)
	{
		return false;
	}

	const bool bChanged =
		BlockTileTypes[BlockIndex] != ResolvedTileType ||
		BlockRotations[BlockIndex] != ResolvedRotation;

	if (!bChanged)
	{
		return false;
	}

	BlockTileTypes[BlockIndex] = ResolvedTileType;
	BlockRotations[BlockIndex] = ResolvedRotation;
	OutChangedPositions.Add(GridPosition);
	return true;
}

void ATileMapTerrainActor::RebuildChunksForPositions(
	const TSet<FIntVector>& GridPositions
)
{
	TSet<FIntVector> ChunksToRebuild;

	for (const FIntVector& GridPosition : GridPositions)
	{
		ChunksToRebuild.Add(
			GetChunkCoordinate(GridPosition)
		);
	}

	for (const FIntVector& ChunkCoordinate : ChunksToRebuild)
	{
		RebuildChunk(ChunkCoordinate);
	}
}

void ATileMapTerrainActor::RefreshAutoTilesAround(
	const FIntVector& GridPosition
)
{
	TSet<FIntVector> PositionsToCheck;

	for (int32 ZOffset = -1; ZOffset <= 1; ++ZOffset)
	{
		for (int32 XOffset = -1; XOffset <= 1; ++XOffset)
		{
			for (int32 YOffset = -1; YOffset <= 1; ++YOffset)
			{
				PositionsToCheck.Add(
					GridPosition +
					FIntVector(XOffset, YOffset, ZOffset)
				);
			}
		}
	}

	TSet<FIntVector> ChangedPositions;

	for (const FIntVector& PositionToCheck : PositionsToCheck)
	{
		ResolveAutoTileAt(
			PositionToCheck,
			ChangedPositions
		);
	}

	// Include the complete local neighborhood so removed and newly created
	// instances are rebuilt even when no auto variant changed.
	for (const FIntVector& PositionToCheck : PositionsToCheck)
	{
		ChangedPositions.Add(PositionToCheck);
	}
	RebuildChunksForPositions(ChangedPositions);
}

void ATileMapTerrainActor::ResolveAllAutoTiles()
{
	TSet<FIntVector> ChangedPositions;

	for (const FIntVector& GridPosition : OccupiedBlocks)
	{
		ResolveAutoTileAt(
			GridPosition,
			ChangedPositions
		);
	}
}

FText ATileMapTerrainActor::GetTileDisplayName(
	int32 TileType
) const
{
	const int32 SafeTileType = ClampTileType(TileType);

	if (SafeTileType == 0)
	{
		return FText::FromString(TEXT("Default Block"));
	}

	const FTileMapTileDefinition* Definition =
		GetTileDefinition(SafeTileType);

	if (
		Definition &&
		!Definition->TileName.IsNone()
		)
	{
		return FText::FromString(
			Definition->TileName.ToString()
		);
	}

	return FText::FromString(
		FString::Printf(
			TEXT("Palette Tile %d"),
			SafeTileType
		)
	);
}

UStaticMesh* ATileMapTerrainActor::GetTileMesh(
	int32 TileType
) const
{
	const FTileMapTileDefinition* Definition =
		GetTileDefinition(ClampTileType(TileType));

	if (Definition && Definition->Mesh)
	{
		return Definition->Mesh;
	}

	return BlockMesh;
}

UMaterialInterface*
ATileMapTerrainActor::GetTileMaterialOverride(
	int32 TileType
) const
{
	// A shared terrain material deliberately wins over palette and source-mesh
	// materials. This keeps generated slants, rebuilt HISM chunks, and baked
	// output visually identical, including on terrain created by older builds.
	if (DefaultTerrainMaterial)
	{
		return DefaultTerrainMaterial;
	}

	const FTileMapTileDefinition* Definition =
		GetTileDefinition(ClampTileType(TileType));

	return Definition
		? Definition->MaterialOverride
		: nullptr;
}

bool ATileMapTerrainActor::UsesLegacyMeshInContinuousMode(
	int32 TileType
) const
{
	const FTileMapTileDefinition* Definition =
		GetTileDefinition(ClampTileType(TileType));

	return
		Definition &&
		(
			Definition->AutoShape == ETileMapAutoShape::Ramp ||
			Definition->AutoShape == ETileMapAutoShape::DiagonalEdge
		);
}

bool ATileMapTerrainActor::IsContinuousSurfaceBlock(
	const FIntVector& GridPosition
) const
{
	return
		bUseContinuousTerrainPrototype &&
		HasBlock(GridPosition) &&
		!UsesLegacyMeshInContinuousMode(
			GetBlockTileType(GridPosition)
		);
}

float ATileMapTerrainActor::GetContinuousTopSurfaceZ(
	float LocalX,
	float LocalY,
	int32 TopGridZ,
	FVector& OutNormal
) const
{
	const float SafeGridSize = FMath::Max(GridSize, 1.0f);
	const float ChamferWidth = FMath::Clamp(
		ContinuousChamferWidth,
		1.0f,
		SafeGridSize * 0.3f
	);
	const float ChamferDepth = FMath::Clamp(
		ContinuousChamferDepth,
		1.0f,
		SafeGridSize * 0.25f
	);
	const float FlatTopZ = TopGridZ * SafeGridSize;
	const int32 BlockLayer = TopGridZ - 1;
	const FVector2D SamplePoint(LocalX, LocalY);
	const int32 CenterGridX =
		FMath::FloorToInt(LocalX / SafeGridSize);
	const int32 CenterGridY =
		FMath::FloorToInt(LocalY / SafeGridSize);

	float ClosestDistanceSquared = TNumericLimits<float>::Max();
	FVector2D ClosestInwardDirection = FVector2D::ZeroVector;

	struct FDropEdge
	{
		FIntVector NeighborOffset;
		FVector2D Start;
		FVector2D End;
		FVector2D InwardNormal;
	};

	for (int32 XOffset = -2; XOffset <= 2; ++XOffset)
	{
		for (int32 YOffset = -2; YOffset <= 2; ++YOffset)
		{
			const FIntVector SurfaceBlock(
				CenterGridX + XOffset,
				CenterGridY + YOffset,
				BlockLayer
			);

			if (
				!IsContinuousSurfaceBlock(SurfaceBlock) ||
				HasBlock(SurfaceBlock + FIntVector(0, 0, 1))
				)
			{
				continue;
			}

			const float MinimumX =
				SurfaceBlock.X * SafeGridSize;
			const float MinimumY =
				SurfaceBlock.Y * SafeGridSize;
			const float MaximumX = MinimumX + SafeGridSize;
			const float MaximumY = MinimumY + SafeGridSize;

			const FDropEdge DropEdges[4] =
			{
				{
					FIntVector(1, 0, 0),
					FVector2D(MaximumX, MinimumY),
					FVector2D(MaximumX, MaximumY),
					FVector2D(-1.0f, 0.0f)
				},
				{
					FIntVector(-1, 0, 0),
					FVector2D(MinimumX, MinimumY),
					FVector2D(MinimumX, MaximumY),
					FVector2D(1.0f, 0.0f)
				},
				{
					FIntVector(0, 1, 0),
					FVector2D(MinimumX, MaximumY),
					FVector2D(MaximumX, MaximumY),
					FVector2D(0.0f, -1.0f)
				},
				{
					FIntVector(0, -1, 0),
					FVector2D(MinimumX, MinimumY),
					FVector2D(MaximumX, MinimumY),
					FVector2D(0.0f, 1.0f)
				}
			};

			for (const FDropEdge& DropEdge : DropEdges)
			{
				// A chamfer belongs only to an actual drop-off. A neighboring
				// occupied block suppresses it, including at the foot of a taller
				// stack where the lower ground must remain flat against the wall.
				if (HasBlock(SurfaceBlock + DropEdge.NeighborOffset))
				{
					continue;
				}

				const FVector2D EdgeVector =
					DropEdge.End - DropEdge.Start;
				const float EdgeLengthSquared =
					EdgeVector.SizeSquared();
				const float EdgeAlpha =
					EdgeLengthSquared > SMALL_NUMBER
					? FMath::Clamp(
						FVector2D::DotProduct(
							SamplePoint - DropEdge.Start,
							EdgeVector
						) / EdgeLengthSquared,
						0.0f,
						1.0f
					)
					: 0.0f;
				const FVector2D ClosestPoint =
					DropEdge.Start + (EdgeVector * EdgeAlpha);
				const FVector2D FromEdge =
					SamplePoint - ClosestPoint;
				const float DistanceSquared =
					FromEdge.SizeSquared();

				if (DistanceSquared >= ClosestDistanceSquared)
				{
					continue;
				}

				ClosestDistanceSquared = DistanceSquared;
				ClosestInwardDirection =
					DistanceSquared > KINDA_SMALL_NUMBER
					? FromEdge.GetSafeNormal()
					: DropEdge.InwardNormal;
			}
		}
	}

	OutNormal = FVector::UpVector;

	if (ClosestDistanceSquared == TNumericLimits<float>::Max())
	{
		return FlatTopZ;
	}

	const float ClosestDistance =
		FMath::Sqrt(ClosestDistanceSquared);

	if (ClosestDistance >= ChamferWidth)
	{
		return FlatTopZ;
	}

	const float SurfaceAlpha =
		FMath::Clamp(
			ClosestDistance / ChamferWidth,
			0.0f,
			1.0f
		);
	const float Slope = ChamferDepth / ChamferWidth;

	OutNormal = FVector(
		-ClosestInwardDirection.X * Slope,
		-ClosestInwardDirection.Y * Slope,
		1.0f
	).GetSafeNormal();

	return FlatTopZ -
		(ChamferDepth * (1.0f - SurfaceAlpha));
}

int32 ATileMapTerrainActor::GetBlockTileType(
	const FIntVector& GridPosition
) const
{
	const int32 BlockIndex =
		FindBlockIndex(GridPosition);

	if (!BlockTileTypes.IsValidIndex(BlockIndex))
	{
		return 0;
	}

	return ClampTileType(BlockTileTypes[BlockIndex]);
}

uint8 ATileMapTerrainActor::GetBlockRotation(
	const FIntVector& GridPosition
) const
{
	const int32 BlockIndex =
		FindBlockIndex(GridPosition);

	if (!BlockRotations.IsValidIndex(BlockIndex))
	{
		return 0;
	}

	return BlockRotations[BlockIndex] % 4;
}

FTransform ATileMapTerrainActor::GetBlockLocalTransform(
	const FIntVector& GridPosition
) const
{
	const int32 TileType =
		GetBlockTileType(GridPosition);

	const uint8 QuarterTurns =
		GetBlockRotation(GridPosition);

	const FTileMapTileDefinition* Definition =
		GetTileDefinition(TileType);

	const float GridScale =
		FMath::Max(GridSize, 1.0f) / 100.0f;

	const FVector DefinitionScale =
		Definition
		? Definition->MeshScale
		: FVector::OneVector;

	const FVector TilePivotOffset =
		Definition
		? Definition->PivotOffset
		: FVector::ZeroVector;

	const FQuat Rotation(
		FVector::UpVector,
		FMath::DegreesToRadians(
			static_cast<float>(QuarterTurns) * 90.0f
		)
	);

	const FVector Location =
		GridToLocal(GridPosition) +
		Rotation.RotateVector(
			TilePivotOffset * GridScale
		);

	return FTransform(
		Rotation,
		Location,
		DefinitionScale * GridScale
	);
}

bool ATileMapTerrainActor::AddBlock(
	const FIntVector& GridPosition,
	int32 TileType,
	uint8 QuarterTurns
)
{
	if (HasBlock(GridPosition))
	{
		return false;
	}

	NormalizeBlockMetadata();

	const int32 NewIndex =
		OccupiedBlocks.Add(GridPosition);

	BlockTileTypes.Add(
		ClampTileType(TileType)
	);

	BlockRotations.Add(QuarterTurns % 4);

	OccupancyLookup.Add(GridPosition);
	BlockIndexLookup.Add(GridPosition, NewIndex);

	const FIntVector ChunkCoordinate =
		GetChunkCoordinate(GridPosition);

	ChunkBlocksLookup.FindOrAdd(
		ChunkCoordinate
	).Add(GridPosition);

	RefreshAutoTilesAround(GridPosition);
	return true;
}

bool ATileMapTerrainActor::RemoveBlock(
	const FIntVector& GridPosition
)
{
	const int32 BlockIndex =
		FindBlockIndex(GridPosition);

	if (BlockIndex == INDEX_NONE)
	{
		return false;
	}

	const FIntVector ChunkCoordinate =
		GetChunkCoordinate(GridPosition);

	OccupiedBlocks.RemoveAt(BlockIndex);

	if (BlockTileTypes.IsValidIndex(BlockIndex))
	{
		BlockTileTypes.RemoveAt(BlockIndex);
	}

	if (BlockRotations.IsValidIndex(BlockIndex))
	{
		BlockRotations.RemoveAt(BlockIndex);
	}

	OccupancyLookup.Remove(GridPosition);
	BlockIndexLookup.Remove(GridPosition);

	for (
		int32 Index = BlockIndex;
		Index < OccupiedBlocks.Num();
		++Index
		)
	{
		BlockIndexLookup.Add(
			OccupiedBlocks[Index],
			Index
		);
	}

	TArray<FIntVector>* ChunkBlocks =
		ChunkBlocksLookup.Find(ChunkCoordinate);

	if (ChunkBlocks)
	{
		ChunkBlocks->RemoveSingle(GridPosition);

		if (ChunkBlocks->Num() == 0)
		{
			ChunkBlocksLookup.Remove(ChunkCoordinate);
		}
	}

	RefreshAutoTilesAround(GridPosition);
	return true;
}

bool ATileMapTerrainActor::RemoveBlocks(
	const TArray<FIntVector>& GridPositions
)
{
	if (GridPositions.Num() == 0)
	{
		return false;
	}

	TSet<FIntVector> UniquePositions;
	TArray<int32> BlockIndices;

	for (const FIntVector& GridPosition : GridPositions)
	{
		if (UniquePositions.Contains(GridPosition))
		{
			continue;
		}

		const int32 BlockIndex = FindBlockIndex(GridPosition);

		if (BlockIndex == INDEX_NONE)
		{
			continue;
		}

		UniquePositions.Add(GridPosition);
		BlockIndices.Add(BlockIndex);
	}

	if (BlockIndices.Num() == 0)
	{
		return false;
	}

	// Removing from the highest index down preserves all remaining indices.
	BlockIndices.Sort(
		[](int32 Left, int32 Right)
		{
			return Left > Right;
		}
	);

	for (const int32 BlockIndex : BlockIndices)
	{
		OccupiedBlocks.RemoveAt(BlockIndex);

		if (BlockTileTypes.IsValidIndex(BlockIndex))
		{
			BlockTileTypes.RemoveAt(BlockIndex);
		}

		if (BlockRotations.IsValidIndex(BlockIndex))
		{
			BlockRotations.RemoveAt(BlockIndex);
		}
	}

	RebuildDerivedLookups();

	TSet<FIntVector> PositionsToRefresh;

	for (const FIntVector& RemovedPosition : UniquePositions)
	{
		for (int32 ZOffset = -1; ZOffset <= 1; ++ZOffset)
		{
			for (int32 XOffset = -1; XOffset <= 1; ++XOffset)
			{
				for (int32 YOffset = -1; YOffset <= 1; ++YOffset)
				{
					PositionsToRefresh.Add(
						RemovedPosition +
						FIntVector(XOffset, YOffset, ZOffset)
					);
				}
			}
		}
	}

	TSet<FIntVector> ChangedPositions = PositionsToRefresh;

	for (const FIntVector& Position : PositionsToRefresh)
	{
		ResolveAutoTileAt(Position, ChangedPositions);
	}

	RebuildChunksForPositions(ChangedPositions);
	return true;
}

bool ATileMapTerrainActor::MoveBlock(
	const FIntVector& FromGridPosition,
	const FIntVector& ToGridPosition
)
{
	if (FromGridPosition == ToGridPosition)
	{
		return HasBlock(FromGridPosition);
	}

	if (
		!HasBlock(FromGridPosition) ||
		HasBlock(ToGridPosition)
		)
	{
		return false;
	}

	const int32 BlockIndex =
		FindBlockIndex(FromGridPosition);

	if (BlockIndex == INDEX_NONE)
	{
		return false;
	}

	OccupiedBlocks[BlockIndex] = ToGridPosition;

	OccupancyLookup.Remove(FromGridPosition);
	OccupancyLookup.Add(ToGridPosition);

	BlockIndexLookup.Remove(FromGridPosition);
	BlockIndexLookup.Add(ToGridPosition, BlockIndex);

	const FIntVector OldChunk =
		GetChunkCoordinate(FromGridPosition);

	const FIntVector NewChunk =
		GetChunkCoordinate(ToGridPosition);

	TArray<FIntVector>* OldChunkBlocks =
		ChunkBlocksLookup.Find(OldChunk);

	if (OldChunkBlocks)
	{
		OldChunkBlocks->RemoveSingle(FromGridPosition);

		if (OldChunkBlocks->Num() == 0)
		{
			ChunkBlocksLookup.Remove(OldChunk);
		}
	}

	ChunkBlocksLookup.FindOrAdd(
		NewChunk
	).Add(ToGridPosition);

	RefreshAutoTilesAround(FromGridPosition);
	RefreshAutoTilesAround(ToGridPosition);

	return true;
}

bool ATileMapTerrainActor::SetBlockTileType(
	const FIntVector& GridPosition,
	int32 TileType
)
{
	const int32 BlockIndex =
		FindBlockIndex(GridPosition);

	if (!BlockTileTypes.IsValidIndex(BlockIndex))
	{
		return false;
	}

	const int32 SafeTileType =
		ClampTileType(TileType);

	if (BlockTileTypes[BlockIndex] == SafeTileType)
	{
		return false;
	}

	BlockTileTypes[BlockIndex] = SafeTileType;
	RefreshAutoTilesAround(GridPosition);
	return true;
}

bool ATileMapTerrainActor::RotateBlock(
	const FIntVector& GridPosition,
	int32 QuarterTurnDelta
)
{
	const int32 BlockIndex =
		FindBlockIndex(GridPosition);

	if (!BlockRotations.IsValidIndex(BlockIndex))
	{
		return false;
	}

	const int32 CurrentRotation =
		static_cast<int32>(BlockRotations[BlockIndex]);

	BlockRotations[BlockIndex] =
		static_cast<uint8>(
			(CurrentRotation + QuarterTurnDelta % 4 + 4) % 4
		);

	RebuildChunk(GetChunkCoordinate(GridPosition));
	return true;
}

bool ATileMapTerrainActor::SetBlocksVisual(
	const TArray<FIntVector>& GridPositions,
	const TArray<int32>& TileTypes,
	uint8 QuarterTurns
)
{
	if (
		GridPositions.Num() == 0 ||
		GridPositions.Num() != TileTypes.Num()
		)
	{
		return false;
	}

	TArray<int32> BlockIndices;
	BlockIndices.Reserve(GridPositions.Num());

	// Validate the complete run before changing anything.
	for (const FIntVector& GridPosition : GridPositions)
	{
		const int32 BlockIndex = FindBlockIndex(GridPosition);

		if (
			!BlockTileTypes.IsValidIndex(BlockIndex) ||
			!BlockRotations.IsValidIndex(BlockIndex)
			)
		{
			return false;
		}

		BlockIndices.Add(BlockIndex);
	}

	const uint8 SafeRotation = QuarterTurns % 4;
	TSet<FIntVector> ChangedChunks;
	bool bChanged = false;

	for (int32 ItemIndex = 0;
		ItemIndex < GridPositions.Num();
		++ItemIndex)
	{
		const int32 BlockIndex = BlockIndices[ItemIndex];
		const int32 SafeTileType = ClampTileType(TileTypes[ItemIndex]);

		if (
			BlockTileTypes[BlockIndex] == SafeTileType &&
			BlockRotations[BlockIndex] == SafeRotation
			)
		{
			continue;
		}

		BlockTileTypes[BlockIndex] = SafeTileType;
		BlockRotations[BlockIndex] = SafeRotation;
		ChangedChunks.Add(
			GetChunkCoordinate(GridPositions[ItemIndex])
		);
		bChanged = true;
	}

	for (const FIntVector& ChunkCoordinate : ChangedChunks)
	{
		RebuildChunk(ChunkCoordinate);
	}

	return bChanged;
}

void ATileMapTerrainActor::ClearBlocks()
{
	OccupiedBlocks.Reset();
	BlockTileTypes.Reset();
	BlockRotations.Reset();
	OccupancyLookup.Reset();
	BlockIndexLookup.Reset();
	ChunkBlocksLookup.Reset();
	DestroyAllChunkComponents();
}

void ATileMapTerrainActor::CreateTestGrid(
	int32 GridWidth,
	int32 GridHeight
)
{
	OccupiedBlocks.Reset();
	BlockTileTypes.Reset();
	BlockRotations.Reset();

	GridWidth = FMath::Max(GridWidth, 1);
	GridHeight = FMath::Max(GridHeight, 1);

	for (int32 X = 0; X < GridWidth; ++X)
	{
		for (int32 Y = 0; Y < GridHeight; ++Y)
		{
			int32 HighestLayer = 0;

			if (
				X >= 3 && X <= 6 &&
				Y >= 3 && Y <= 6
				)
			{
				HighestLayer = 1;
			}

			if (
				X >= 4 && X <= 5 &&
				Y >= 4 && Y <= 5
				)
			{
				HighestLayer = 2;
			}

			for (
				int32 Layer = 0;
				Layer <= HighestLayer;
				++Layer
				)
			{
				OccupiedBlocks.Add(
					FIntVector(X, Y, Layer)
				);

				BlockTileTypes.Add(0);
				BlockRotations.Add(0);
			}
		}
	}

	RebuildAllChunks();
}

bool ATileMapTerrainActor::GetGridPositionFromHit(
	const FHitResult& HitResult,
	FIntVector& OutGridPosition
) const
{
	if (HitResult.GetActor() != this)
	{
		return false;
	}

	const FVector SafeNormal =
		HitResult.ImpactNormal.GetSafeNormal();

	const float NudgeDistance =
		FMath::Max(GridSize * 0.01f, 0.1f);

	const FVector InsidePoint =
		HitResult.ImpactPoint -
		(SafeNormal * NudgeDistance);

	OutGridPosition = WorldToGrid(InsidePoint);

	if (HasBlock(OutGridPosition))
	{
		return true;
	}

	if (!bUseContinuousTerrainPrototype)
	{
		return false;
	}

	// The continuous top-edge chamfer can place a collision triangle directly
	// on a logical cell boundary. If the normal nudge lands in the neighboring
	// empty cell, recover the closest occupied source block for cursor tools.
	const FVector LocalImpactPoint =
		GetActorTransform().InverseTransformPosition(
			HitResult.ImpactPoint
		);
	const float SafeGridSize = FMath::Max(GridSize, 1.0f);
	float BestDistanceSquared = TNumericLimits<float>::Max();
	FIntVector BestPosition = OutGridPosition;

	for (int32 ZOffset = -1; ZOffset <= 1; ++ZOffset)
	{
		for (int32 XOffset = -1; XOffset <= 1; ++XOffset)
		{
			for (int32 YOffset = -1; YOffset <= 1; ++YOffset)
			{
				const FIntVector Candidate =
					OutGridPosition +
					FIntVector(XOffset, YOffset, ZOffset);

				if (!HasBlock(Candidate))
				{
					continue;
				}

				const FVector Minimum(
					Candidate.X * SafeGridSize,
					Candidate.Y * SafeGridSize,
					Candidate.Z * SafeGridSize
				);
				const FVector Maximum =
					Minimum + FVector(SafeGridSize);
				const FVector ClosestPoint(
					FMath::Clamp(
						LocalImpactPoint.X,
						Minimum.X,
						Maximum.X
					),
					FMath::Clamp(
						LocalImpactPoint.Y,
						Minimum.Y,
						Maximum.Y
					),
					FMath::Clamp(
						LocalImpactPoint.Z,
						Minimum.Z,
						Maximum.Z
					)
				);
				const float DistanceSquared =
					FVector::DistSquared(
						LocalImpactPoint,
						ClosestPoint
					);

				if (DistanceSquared < BestDistanceSquared)
				{
					BestDistanceSquared = DistanceSquared;
					BestPosition = Candidate;
				}
			}
		}
	}

	if (BestDistanceSquared < TNumericLimits<float>::Max())
	{
		OutGridPosition = BestPosition;
		return true;
	}

	return false;
}

bool ATileMapTerrainActor::GetAdjacentGridPositionFromHit(
	const FHitResult& HitResult,
	FIntVector& OutGridPosition
) const
{
	if (HitResult.GetActor() != this)
	{
		return false;
	}

	FIntVector HitGridPosition;

	if (
		!GetGridPositionFromHit(
			HitResult,
			HitGridPosition
		)
		)
	{
		return false;
	}

	const FVector LocalNormal =
		GetActorTransform()
		.InverseTransformVectorNoScale(
			HitResult.ImpactNormal
		)
		.GetSafeNormal();

	const FVector AbsoluteNormal =
		LocalNormal.GetAbs();

	FIntVector NeighborOffset(0, 0, 0);

	if (
		AbsoluteNormal.X >= AbsoluteNormal.Y &&
		AbsoluteNormal.X >= AbsoluteNormal.Z
		)
	{
		NeighborOffset.X = LocalNormal.X >= 0.0f ? 1 : -1;
	}
	else if (AbsoluteNormal.Y >= AbsoluteNormal.Z)
	{
		NeighborOffset.Y = LocalNormal.Y >= 0.0f ? 1 : -1;
	}
	else
	{
		NeighborOffset.Z = LocalNormal.Z >= 0.0f ? 1 : -1;
	}

	OutGridPosition = HitGridPosition + NeighborOffset;
	return true;
}

void ATileMapTerrainActor::NormalizeBlockMetadata()
{
	BlockTileTypes.SetNum(OccupiedBlocks.Num());
	BlockRotations.SetNum(OccupiedBlocks.Num());

	for (int32 Index = 0; Index < OccupiedBlocks.Num(); ++Index)
	{
		BlockTileTypes[Index] =
			ClampTileType(BlockTileTypes[Index]);

		BlockRotations[Index] %= 4;
	}
}

void ATileMapTerrainActor::RebuildDerivedLookups()
{
	NormalizeBlockMetadata();

	OccupancyLookup.Reset();
	BlockIndexLookup.Reset();
	ChunkBlocksLookup.Reset();

	for (
		int32 Index = 0;
		Index < OccupiedBlocks.Num();
		++Index
		)
	{
		const FIntVector& GridPosition =
			OccupiedBlocks[Index];

		if (OccupancyLookup.Contains(GridPosition))
		{
			continue;
		}

		OccupancyLookup.Add(GridPosition);
		BlockIndexLookup.Add(GridPosition, Index);

		ChunkBlocksLookup.FindOrAdd(
			GetChunkCoordinate(GridPosition)
		).Add(GridPosition);
	}
}

UProceduralMeshComponent*
ATileMapTerrainActor::FindOrCreateContinuousChunkComponent(
	const FIntVector& ChunkCoordinate
)
{
	UProceduralMeshComponent** ExistingComponent =
		ContinuousChunkComponentLookup.Find(ChunkCoordinate);

	if (ExistingComponent && IsValid(*ExistingComponent))
	{
		return *ExistingComponent;
	}

	const FName ComponentName =
		MakeUniqueObjectName(
			this,
			UProceduralMeshComponent::StaticClass(),
			FName(
				*FString::Printf(
					TEXT("TileContinuousChunk_%d_%d_%d"),
					ChunkCoordinate.X,
					ChunkCoordinate.Y,
					ChunkCoordinate.Z
				)
			)
		);

	UProceduralMeshComponent* NewComponent =
		NewObject<UProceduralMeshComponent>(
			this,
			ComponentName,
			RF_Transient |
			RF_DuplicateTransient |
			RF_TextExportTransient
		);

	if (!NewComponent)
	{
		return nullptr;
	}

	// Like the HISM components, this is a derived render/collision cache. The
	// serialized block arrays remain the only transactional terrain data.
	NewComponent->ClearFlags(RF_Transactional);
	NewComponent->CreationMethod = EComponentCreationMethod::Instance;
	NewComponent->SetupAttachment(SceneRoot);
	NewComponent->SetRelativeTransform(FTransform::Identity);
	NewComponent->SetMobility(EComponentMobility::Movable);
	NewComponent->SetGenerateOverlapEvents(false);
	NewComponent->SetCollisionProfileName(TEXT("BlockAll"));
	NewComponent->SetCastShadow(true);
	NewComponent->bCastStaticShadow = false;
	NewComponent->bCastDynamicShadow = true;
	NewComponent->bUseComplexAsSimpleCollision = true;
	NewComponent->SetCollisionEnabled(
		bGenerateCollision
		? ECollisionEnabled::QueryAndPhysics
		: ECollisionEnabled::NoCollision
	);

	AddOwnedComponent(NewComponent);
	NewComponent->RegisterComponent();

	ContinuousChunkComponents.Add(NewComponent);
	ContinuousChunkComponentLookup.Add(
		ChunkCoordinate,
		NewComponent
	);

	return NewComponent;
}

void ATileMapTerrainActor::BuildContinuousChunk(
	const FIntVector& ChunkCoordinate,
	const TArray<FIntVector>& ChunkBlocks
)
{
	TMap<int32, FTileMapContinuousSection> SectionsByTileType;
	const int32 ChamferSubdivisions = FMath::Clamp(
		ContinuousChamferSubdivisions,
		2,
		16
	);
	const int32 CornerSubdivisions = FMath::Clamp(
		ChamferSubdivisions / 2,
		2,
		8
	);

	struct FContinuousWall
	{
		FIntVector NeighborOffset;
		FVector Normal;
		FVector2D BottomAOffset;
		FVector2D BottomBOffset;
	};

	const FContinuousWall Walls[4] =
	{
		{
			FIntVector(1, 0, 0),
			FVector(1, 0, 0),
			FVector2D(1, 0),
			FVector2D(1, 1)
		},
		{
			FIntVector(-1, 0, 0),
			FVector(-1, 0, 0),
			FVector2D(0, 1),
			FVector2D(0, 0)
		},
		{
			FIntVector(0, 1, 0),
			FVector(0, 1, 0),
			FVector2D(1, 1),
			FVector2D(0, 1)
		},
		{
			FIntVector(0, -1, 0),
			FVector(0, -1, 0),
			FVector2D(0, 0),
			FVector2D(1, 0)
		}
	};

	const float SafeGridSize = FMath::Max(GridSize, 1.0f);
	const float CornerRadius = FMath::Clamp(
		ContinuousCliffCornerRadius,
		1.0f,
		SafeGridSize * 0.2f
	);
	const float ChamferWidth = FMath::Clamp(
		ContinuousChamferWidth,
		1.0f,
		SafeGridSize * 0.3f
	);
	const float ChamferDepth = FMath::Clamp(
		ContinuousChamferDepth,
		1.0f,
		SafeGridSize * 0.25f
	);
	const float EdgeIrregularity = FMath::Clamp(
		ContinuousEdgeIrregularity,
		0.0f,
		FMath::Min(
			SafeGridSize * 0.1f,
			ChamferWidth * 0.75f
		)
	);
	const float EdgeWavelength = FMath::Clamp(
		ContinuousEdgeWavelength,
		SafeGridSize * 0.25f,
		SafeGridSize * 2.0f
	);
	const float CornerAlpha = CornerRadius / SafeGridSize;
	const float ChamferAlpha = ChamferWidth / SafeGridSize;

	TArray<float> RoundedSurfaceAlphas;
	RoundedSurfaceAlphas.Reserve(
		(CornerSubdivisions * 2) + 7
	);

	auto AddSurfaceAlpha =
		[&RoundedSurfaceAlphas](float Alpha)
		{
			const float SafeAlpha = FMath::Clamp(
				Alpha,
				0.0f,
				1.0f
			);

			for (const float ExistingAlpha : RoundedSurfaceAlphas)
			{
				if (FMath::IsNearlyEqual(ExistingAlpha, SafeAlpha))
				{
					return;
				}
			}

			RoundedSurfaceAlphas.Add(SafeAlpha);
		};

	AddSurfaceAlpha(0.0f);
	AddSurfaceAlpha(1.0f);
	AddSurfaceAlpha(ChamferAlpha);
	AddSurfaceAlpha(1.0f - ChamferAlpha);
	AddSurfaceAlpha(0.5f);

	if (EdgeIrregularity > KINDA_SMALL_NUMBER)
	{
		AddSurfaceAlpha(0.25f);
		AddSurfaceAlpha(0.75f);
	}

	for (
		int32 CornerStep = 1;
		CornerStep <= CornerSubdivisions;
		++CornerStep
		)
	{
		const float CornerStepAlpha =
			CornerAlpha *
			(
				static_cast<float>(CornerStep) /
				static_cast<float>(CornerSubdivisions)
			);

		AddSurfaceAlpha(CornerStepAlpha);
		AddSurfaceAlpha(1.0f - CornerStepAlpha);
	}

	RoundedSurfaceAlphas.Sort();

	TArray<float> FlatSurfaceAlphas;
	FlatSurfaceAlphas.Add(0.0f);
	FlatSurfaceAlphas.Add(1.0f);

	auto IsConvexCorner =
		[this](
			const FIntVector& BlockPosition,
			int32 CornerX,
			int32 CornerY
		)
		{
			if (!IsContinuousSurfaceBlock(BlockPosition))
			{
				return false;
			}

			const int32 XDirection = CornerX == 0 ? -1 : 1;
			const int32 YDirection = CornerY == 0 ? -1 : 1;

			return
				!HasBlock(
					BlockPosition +
					FIntVector(XDirection, 0, 0)
				) &&
				!HasBlock(
					BlockPosition +
					FIntVector(0, YDirection, 0)
				);
		};

	auto IsRoundableConcaveCorner =
		[this](
			int32 CornerGridX,
			int32 CornerGridY,
			int32 Layer
		)
		{
			const FIntVector Cells[4] =
			{
				FIntVector(CornerGridX - 1, CornerGridY - 1, Layer),
				FIntVector(CornerGridX, CornerGridY - 1, Layer),
				FIntVector(CornerGridX - 1, CornerGridY, Layer),
				FIntVector(CornerGridX, CornerGridY, Layer)
			};

			TArray<FIntVector, TInlineAllocator<4>> SurfaceCells;
			int32 OccupiedCellCount = 0;

			for (const FIntVector& Cell : Cells)
			{
				if (HasBlock(Cell))
				{
					++OccupiedCellCount;
				}

				if (IsContinuousSurfaceBlock(Cell))
				{
					SurfaceCells.Add(Cell);
				}
			}

			if (OccupiedCellCount != 3 || SurfaceCells.Num() != 3)
			{
				return false;
			}

			auto HasUniformLayerState =
				[this, &SurfaceCells](const FIntVector& LayerOffset)
				{
					const bool bFirstOccupied =
						HasBlock(SurfaceCells[0] + LayerOffset);
					const bool bFirstContinuous =
						IsContinuousSurfaceBlock(
							SurfaceCells[0] + LayerOffset
						);

					for (
						int32 CellIndex = 1;
						CellIndex < SurfaceCells.Num();
						++CellIndex
						)
					{
						if (
							HasBlock(
								SurfaceCells[CellIndex] + LayerOffset
							) != bFirstOccupied ||
							IsContinuousSurfaceBlock(
								SurfaceCells[CellIndex] + LayerOffset
							) != bFirstContinuous
							)
						{
							return false;
						}
					}

					return true;
				};

			if (!HasUniformLayerState(FIntVector(0, 0, 1)))
			{
				return false;
			}

			return
				Layer == 0 ||
				HasUniformLayerState(FIntVector(0, 0, -1));
		};

	for (const FIntVector& GridPosition : ChunkBlocks)
	{
		if (!IsContinuousSurfaceBlock(GridPosition))
		{
			continue;
		}

		const int32 TileType = GetBlockTileType(GridPosition);
		FTileMapContinuousSection& Section =
			SectionsByTileType.FindOrAdd(TileType);
		const FVector BlockMinimum(
			GridPosition.X * SafeGridSize,
			GridPosition.Y * SafeGridSize,
			GridPosition.Z * SafeGridSize
		);
		const FVector2D BlockMinimum2D(
			BlockMinimum.X,
			BlockMinimum.Y
		);
		bool bConvexCorners[2][2];
		bool bEdgeBlendCorners[2][2];
		bool bHasConvexCorner = false;

		for (int32 CornerX = 0; CornerX <= 1; ++CornerX)
		{
			for (int32 CornerY = 0; CornerY <= 1; ++CornerY)
			{
				bConvexCorners[CornerX][CornerY] =
					IsConvexCorner(
						GridPosition,
						CornerX,
						CornerY
					);
				bHasConvexCorner =
					bHasConvexCorner ||
					bConvexCorners[CornerX][CornerY];
				bEdgeBlendCorners[CornerX][CornerY] =
					bConvexCorners[CornerX][CornerY] ||
					IsRoundableConcaveCorner(
						GridPosition.X + CornerX,
						GridPosition.Y + CornerY,
						GridPosition.Z
					);
			}
		}

		auto RoundConvexPoint =
			[&](
				const FVector2D& OriginalPoint,
				FVector2D* OutWallNormal
			)
			{
				if (OutWallNormal)
				{
					*OutWallNormal = FVector2D::ZeroVector;
				}

				for (int32 CornerX = 0; CornerX <= 1; ++CornerX)
				{
					for (int32 CornerY = 0; CornerY <= 1; ++CornerY)
					{
						if (!bConvexCorners[CornerX][CornerY])
						{
							continue;
						}

						const float XDirection =
							CornerX == 0 ? -1.0f : 1.0f;
						const float YDirection =
							CornerY == 0 ? -1.0f : 1.0f;
						const FVector2D CornerPoint(
							BlockMinimum2D.X +
								(CornerX * SafeGridSize),
							BlockMinimum2D.Y +
								(CornerY * SafeGridSize)
						);
						const FVector2D CircleCenter =
							CornerPoint -
							FVector2D(
								XDirection * CornerRadius,
								YDirection * CornerRadius
							);
						const float SignedX =
							(OriginalPoint.X - CircleCenter.X) *
							XDirection;
						const float SignedY =
							(OriginalPoint.Y - CircleCenter.Y) *
							YDirection;

						if (
							SignedX < -KINDA_SMALL_NUMBER ||
							SignedY < -KINDA_SMALL_NUMBER ||
							SignedX > CornerRadius + KINDA_SMALL_NUMBER ||
							SignedY > CornerRadius + KINDA_SMALL_NUMBER
							)
						{
							continue;
						}

						const FVector2D CircleOffset =
							OriginalPoint - CircleCenter;
						const float SquareRadius = FMath::Max(
							FMath::Abs(CircleOffset.X),
							FMath::Abs(CircleOffset.Y)
						);

						if (CircleOffset.SizeSquared() <= SMALL_NUMBER)
						{
							return OriginalPoint;
						}

						const FVector2D RoundedPoint =
							CircleCenter +
							(
								CircleOffset.GetSafeNormal() *
								SquareRadius
							);

						if (OutWallNormal)
						{
							*OutWallNormal =
								(RoundedPoint - CircleCenter)
								.GetSafeNormal();
						}

						return RoundedPoint;
					}
				}

				return OriginalPoint;
			};

		auto BuildConvexCutoutBoundary =
			[&](
				int32 CornerX,
				int32 CornerY,
				float LocalZ,
				TArray<FVector>& OutBoundary
			)
			{
				OutBoundary.Reset();
				const float XDirection =
					CornerX == 0 ? -1.0f : 1.0f;
				const float YDirection =
					CornerY == 0 ? -1.0f : 1.0f;
				const FVector2D CornerPoint(
					BlockMinimum2D.X +
						(CornerX * SafeGridSize),
					BlockMinimum2D.Y +
						(CornerY * SafeGridSize)
				);
				const FVector2D CircleCenter =
					CornerPoint -
					FVector2D(
						XDirection * CornerRadius,
						YDirection * CornerRadius
					);
				TArray<FVector2D> Boundary2D;
				Boundary2D.Add(CornerPoint);

				for (
					int32 CornerStep = 0;
					CornerStep <= CornerSubdivisions;
					++CornerStep
					)
				{
					const float Alpha =
						static_cast<float>(CornerStep) /
						static_cast<float>(CornerSubdivisions);
					const FVector2D Direction =
						FVector2D(
							XDirection * Alpha,
							YDirection
						).GetSafeNormal();

					Boundary2D.Add(
						CircleCenter +
						(Direction * CornerRadius)
					);
				}

				for (
					int32 CornerStep = CornerSubdivisions - 1;
					CornerStep >= 0;
					--CornerStep
					)
				{
					const float Alpha =
						static_cast<float>(CornerStep) /
						static_cast<float>(CornerSubdivisions);
					const FVector2D Direction =
						FVector2D(
							XDirection,
							YDirection * Alpha
						).GetSafeNormal();

					Boundary2D.Add(
						CircleCenter +
						(Direction * CornerRadius)
					);
				}

				for (const FVector2D& BoundaryPoint : Boundary2D)
				{
					OutBoundary.Add(
						FVector(
							BoundaryPoint.X,
							BoundaryPoint.Y,
							LocalZ
						)
					);
				}
			};

		auto AddConvexCutoutPatch =
			[&](
				const TArray<FVector>& Boundary,
				const FVector& SurfaceNormal
			)
			{
				if (Boundary.Num() < 3)
				{
					return;
				}

				for (
					int32 BoundaryIndex = 1;
					BoundaryIndex < Boundary.Num() - 1;
					++BoundaryIndex
					)
				{
					AddContinuousTriangle(
						Section,
						Boundary[0],
						Boundary[BoundaryIndex],
						Boundary[BoundaryIndex + 1],
						SurfaceNormal,
						SurfaceNormal,
						SurfaceNormal,
						SurfaceNormal,
						SafeGridSize
					);
				}
			};

		auto SmoothUnit =
			[](float Value)
			{
				const float ClampedValue = FMath::Clamp(
					Value,
					0.0f,
					1.0f
				);

				return
					ClampedValue *
					ClampedValue *
					(3.0f - (2.0f * ClampedValue));
			};

		auto GetCliffEdgeOffset =
			[&](const FVector2D& OriginalPoint)
			{
				FVector2D EdgeOffset = FVector2D::ZeroVector;

				if (EdgeIrregularity <= KINDA_SMALL_NUMBER)
				{
					return EdgeOffset;
				}

				for (const FContinuousWall& Wall : Walls)
				{
					if (
						HasBlock(
							GridPosition + Wall.NeighborOffset
						)
						)
					{
						continue;
					}

					const FVector2D EdgeStart =
						BlockMinimum2D +
						(Wall.BottomAOffset * SafeGridSize);
					const FVector2D EdgeEnd =
						BlockMinimum2D +
						(Wall.BottomBOffset * SafeGridSize);
					const FVector2D EdgeVector = EdgeEnd - EdgeStart;
					const float EdgeLengthSquared =
						EdgeVector.SizeSquared();

					if (EdgeLengthSquared <= SMALL_NUMBER)
					{
						continue;
					}

					const float EdgeAlpha = FMath::Clamp(
						FVector2D::DotProduct(
							OriginalPoint - EdgeStart,
							EdgeVector
						) / EdgeLengthSquared,
						0.0f,
						1.0f
					);
					const FVector2D ClosestPoint =
						EdgeStart + (EdgeVector * EdgeAlpha);
					const FVector2D FromEdge =
						OriginalPoint - ClosestPoint;
					const FVector2D OutwardNormal(
						Wall.Normal.X,
						Wall.Normal.Y
					);

					if (
						FVector2D::DotProduct(
							FromEdge,
							OutwardNormal
						) > KINDA_SMALL_NUMBER
						)
					{
						continue;
					}

					const float DistanceFromEdge = FromEdge.Size();

					if (DistanceFromEdge >= ChamferWidth)
					{
						continue;
					}

					const int32 CornerAX =
						FMath::RoundToInt(Wall.BottomAOffset.X);
					const int32 CornerAY =
						FMath::RoundToInt(Wall.BottomAOffset.Y);
					const int32 CornerBX =
						FMath::RoundToInt(Wall.BottomBOffset.X);
					const int32 CornerBY =
						FMath::RoundToInt(Wall.BottomBOffset.Y);
					const bool bCornerAtA =
						bEdgeBlendCorners[CornerAX][CornerAY];
					const bool bCornerAtB =
						bEdgeBlendCorners[CornerBX][CornerBY];
					float EndpointBlend = 1.0f;

					if (bCornerAtA)
					{
						EndpointBlend *= SmoothUnit(
							(EdgeAlpha - CornerAlpha) /
							FMath::Max(
								CornerAlpha,
								KINDA_SMALL_NUMBER
							)
						);
					}

					if (bCornerAtB)
					{
						EndpointBlend *= SmoothUnit(
							(
								(1.0f - CornerAlpha) -
								EdgeAlpha
							) /
							FMath::Max(
								CornerAlpha,
								KINDA_SMALL_NUMBER
							)
						);
					}

					const float EdgeBlend = SmoothUnit(
						1.0f -
						(DistanceFromEdge / ChamferWidth)
					) * EndpointBlend;

					if (EdgeBlend <= KINDA_SMALL_NUMBER)
					{
						continue;
					}

					const FVector2D EdgeTangent =
						EdgeVector.GetSafeNormal();
					const float TangentCoordinate =
						FVector2D::DotProduct(
							OriginalPoint,
							EdgeTangent
						);
					const float EdgeLineCoordinate =
						FVector2D::DotProduct(
							EdgeStart,
							OutwardNormal
						);
					const float EdgePhase =
						(EdgeLineCoordinate / SafeGridSize) *
						1.6180339f +
						(Wall.Normal.X * 1.2345f) +
						(Wall.Normal.Y * 2.3456f) +
						(GridPosition.Z * 0.731f);
					const float PrimaryAngle =
						(
							2.0f * PI * TangentCoordinate /
							EdgeWavelength
						) + EdgePhase;
					const float SecondaryAngle =
						(
							2.0f * PI * TangentCoordinate /
							(EdgeWavelength * 0.61f)
						) +
						(EdgePhase * 1.37f) +
						1.234f;
					const float Noise =
						(0.75f * FMath::Sin(PrimaryAngle)) +
						(0.25f * FMath::Sin(SecondaryAngle));

					EdgeOffset +=
						OutwardNormal *
						Noise *
						EdgeIrregularity *
						EdgeBlend;
				}

				if (
					EdgeOffset.SizeSquared() >
					(EdgeIrregularity * EdgeIrregularity)
					)
				{
					EdgeOffset =
						EdgeOffset.GetSafeNormal() *
						EdgeIrregularity;
				}

				return EdgeOffset;
			};

		if (!HasBlock(GridPosition + FIntVector(0, 0, 1)))
		{
			const int32 TopGridZ = GridPosition.Z + 1;
			const float FlatTopZ = TopGridZ * SafeGridSize;
			bool bTouchesChamfer = false;

			for (int32 CornerX = 0; CornerX <= 1; ++CornerX)
			{
				for (int32 CornerY = 0; CornerY <= 1; ++CornerY)
				{
					FVector CornerNormal;
					const float CornerZ = GetContinuousTopSurfaceZ(
						(GridPosition.X + CornerX) * SafeGridSize,
						(GridPosition.Y + CornerY) * SafeGridSize,
						TopGridZ,
						CornerNormal
					);

					if (CornerZ < FlatTopZ - KINDA_SMALL_NUMBER)
					{
						bTouchesChamfer = true;
					}
				}
			}

			const TArray<float>& SurfaceAlphas =
				(bTouchesChamfer || bHasConvexCorner)
				? RoundedSurfaceAlphas
				: FlatSurfaceAlphas;
			const int32 SurfacePointCount = SurfaceAlphas.Num();
			TArray<int32> SurfaceVertexIndices;
			SurfaceVertexIndices.SetNum(
				SurfacePointCount * SurfacePointCount
			);

			for (
				int32 SurfaceY = 0;
				SurfaceY < SurfacePointCount;
				++SurfaceY
				)
			{
				for (
					int32 SurfaceX = 0;
					SurfaceX < SurfacePointCount;
					++SurfaceX
					)
				{
					const float AlphaX = SurfaceAlphas[SurfaceX];
					const float AlphaY = SurfaceAlphas[SurfaceY];
					const FVector2D OriginalPoint(
						(GridPosition.X + AlphaX) * SafeGridSize,
						(GridPosition.Y + AlphaY) * SafeGridSize
					);
					FVector2D SurfacePoint =
						RoundConvexPoint(OriginalPoint, nullptr);
					SurfacePoint +=
						GetCliffEdgeOffset(OriginalPoint);
					FVector SurfaceNormal;
					const float LocalZ = GetContinuousTopSurfaceZ(
						OriginalPoint.X,
						OriginalPoint.Y,
						TopGridZ,
						SurfaceNormal
					);
					const int32 VertexArrayIndex =
						SurfaceY * SurfacePointCount +
						SurfaceX;

					SurfaceVertexIndices[VertexArrayIndex] =
						AddContinuousVertex(
							Section,
							FVector(
								SurfacePoint.X,
								SurfacePoint.Y,
								LocalZ
							),
							SurfaceNormal,
							SafeGridSize
						);
				}
			}

			for (
				int32 SurfaceY = 0;
				SurfaceY < SurfacePointCount - 1;
				++SurfaceY
				)
			{
				for (
					int32 SurfaceX = 0;
					SurfaceX < SurfacePointCount - 1;
					++SurfaceX
					)
				{
					const int32 BottomLeft =
						SurfaceVertexIndices[
							SurfaceY * SurfacePointCount +
							SurfaceX
						];
					const int32 BottomRight =
						SurfaceVertexIndices[
							SurfaceY * SurfacePointCount +
							SurfaceX + 1
						];
					const int32 TopLeft =
						SurfaceVertexIndices[
							(SurfaceY + 1) * SurfacePointCount +
							SurfaceX
						];
					const int32 TopRight =
						SurfaceVertexIndices[
							(SurfaceY + 1) * SurfacePointCount +
							SurfaceX + 1
						];

					Section.Triangles.Add(BottomLeft);
					Section.Triangles.Add(TopRight);
					Section.Triangles.Add(BottomRight);
					Section.Triangles.Add(BottomLeft);
					Section.Triangles.Add(TopLeft);
					Section.Triangles.Add(TopRight);
				}
			}
		}

		if (
			GridPosition.Z > 0 &&
			!HasBlock(GridPosition + FIntVector(0, 0, -1))
			)
		{
			const float BottomZ =
				GridPosition.Z * SafeGridSize;
			TArray<FVector> BottomBoundary;
			const FVector2D BoundaryCorners[4] =
			{
				FVector2D(BlockMinimum.X, BlockMinimum.Y),
				FVector2D(
					BlockMinimum.X + SafeGridSize,
					BlockMinimum.Y
				),
				FVector2D(
					BlockMinimum.X + SafeGridSize,
					BlockMinimum.Y + SafeGridSize
				),
				FVector2D(
					BlockMinimum.X,
					BlockMinimum.Y + SafeGridSize
				)
			};
			const TArray<float>& BottomAlphas =
				bHasConvexCorner
				? RoundedSurfaceAlphas
				: FlatSurfaceAlphas;

			for (int32 EdgeIndex = 0; EdgeIndex < 4; ++EdgeIndex)
			{
				const FVector2D& EdgeStart =
					BoundaryCorners[EdgeIndex];
				const FVector2D& EdgeEnd =
					BoundaryCorners[(EdgeIndex + 1) % 4];

				for (const float EdgeAlpha : BottomAlphas)
				{
					const FVector2D OriginalPoint = FMath::Lerp(
						EdgeStart,
						EdgeEnd,
						EdgeAlpha
					);
					const FVector2D RoundedPoint =
						RoundConvexPoint(OriginalPoint, nullptr);

					if (
						BottomBoundary.Num() > 0 &&
						FVector2D(
							BottomBoundary.Last().X,
							BottomBoundary.Last().Y
						).Equals(RoundedPoint, KINDA_SMALL_NUMBER)
						)
					{
						continue;
					}

					BottomBoundary.Add(
						FVector(
							RoundedPoint.X,
							RoundedPoint.Y,
							BottomZ
						)
					);
				}
			}

			if (
				BottomBoundary.Num() > 1 &&
				FVector2D(
					BottomBoundary[0].X,
					BottomBoundary[0].Y
				).Equals(
					FVector2D(
						BottomBoundary.Last().X,
						BottomBoundary.Last().Y
					),
					KINDA_SMALL_NUMBER
				)
				)
			{
				BottomBoundary.Pop();
			}

			AddContinuousPolygon(
				Section,
				BottomBoundary,
				-FVector::UpVector,
				SafeGridSize,
				true
			);
		}

		for (int32 CornerX = 0; CornerX <= 1; ++CornerX)
		{
			for (int32 CornerY = 0; CornerY <= 1; ++CornerY)
			{
				if (!bConvexCorners[CornerX][CornerY])
				{
					continue;
				}

				TArray<FVector> TransitionBoundary;
				const FIntVector BelowPosition =
					GridPosition + FIntVector(0, 0, -1);
				const FIntVector AbovePosition =
					GridPosition + FIntVector(0, 0, 1);

				if (
					GridPosition.Z > 0 &&
					HasBlock(BelowPosition) &&
					!IsConvexCorner(
						BelowPosition,
						CornerX,
						CornerY
					)
					)
				{
					BuildConvexCutoutBoundary(
						CornerX,
						CornerY,
						BlockMinimum.Z,
						TransitionBoundary
					);
					AddConvexCutoutPatch(
						TransitionBoundary,
						FVector::UpVector
					);
				}

				if (
					HasBlock(AbovePosition) &&
					!IsConvexCorner(
						AbovePosition,
						CornerX,
						CornerY
					)
					)
				{
					BuildConvexCutoutBoundary(
						CornerX,
						CornerY,
						BlockMinimum.Z + SafeGridSize,
						TransitionBoundary
					);
					AddConvexCutoutPatch(
						TransitionBoundary,
						-FVector::UpVector
					);
				}
			}
		}

		for (const FContinuousWall& Wall : Walls)
		{
			if (HasBlock(GridPosition + Wall.NeighborOffset))
			{
				continue;
			}

			const FVector2D OriginalBottomA(
				BlockMinimum.X +
					(Wall.BottomAOffset.X * SafeGridSize),
				BlockMinimum.Y +
					(Wall.BottomAOffset.Y * SafeGridSize)
			);
			const FVector2D OriginalBottomB(
				BlockMinimum.X +
					(Wall.BottomBOffset.X * SafeGridSize),
				BlockMinimum.Y +
					(Wall.BottomBOffset.Y * SafeGridSize)
			);
			const int32 CornerAGridX =
				GridPosition.X +
				FMath::RoundToInt(Wall.BottomAOffset.X);
			const int32 CornerAGridY =
				GridPosition.Y +
				FMath::RoundToInt(Wall.BottomAOffset.Y);
			const int32 CornerBGridX =
				GridPosition.X +
				FMath::RoundToInt(Wall.BottomBOffset.X);
			const int32 CornerBGridY =
				GridPosition.Y +
				FMath::RoundToInt(Wall.BottomBOffset.Y);
			const int32 CornerAX =
				FMath::RoundToInt(Wall.BottomAOffset.X);
			const int32 CornerAY =
				FMath::RoundToInt(Wall.BottomAOffset.Y);
			const int32 CornerBX =
				FMath::RoundToInt(Wall.BottomBOffset.X);
			const int32 CornerBY =
				FMath::RoundToInt(Wall.BottomBOffset.Y);
			const bool bConvexAtA =
				bConvexCorners[CornerAX][CornerAY];
			const bool bConvexAtB =
				bConvexCorners[CornerBX][CornerBY];
			const bool bConcaveAtA =
				IsRoundableConcaveCorner(
					CornerAGridX,
					CornerAGridY,
					GridPosition.Z
				);
			const bool bConcaveAtB =
				IsRoundableConcaveCorner(
					CornerBGridX,
					CornerBGridY,
					GridPosition.Z
				);
			const float StartAlpha =
				bConcaveAtA ? CornerAlpha : 0.0f;
			const float EndAlpha =
				bConcaveAtB ? 1.0f - CornerAlpha : 1.0f;
			const bool bCoveredAbove =
				HasBlock(GridPosition + FIntVector(0, 0, 1));
			const bool bUseWavyLip =
				!bCoveredAbove &&
				EdgeIrregularity > KINDA_SMALL_NUMBER;
			TArray<float> WallAlphas;
			WallAlphas.Add(StartAlpha);
			WallAlphas.Add(EndAlpha);
			const TArray<float>& CandidateWallAlphas =
				(
					bConvexAtA ||
					bConvexAtB ||
					bConcaveAtA ||
					bConcaveAtB ||
					bUseWavyLip
				)
				? RoundedSurfaceAlphas
				: FlatSurfaceAlphas;

			for (const float SurfaceAlpha : CandidateWallAlphas)
			{
				if (
					SurfaceAlpha > StartAlpha + KINDA_SMALL_NUMBER &&
					SurfaceAlpha < EndAlpha - KINDA_SMALL_NUMBER
					)
				{
					WallAlphas.Add(SurfaceAlpha);
				}
			}

			WallAlphas.Sort();

			for (
				int32 AlphaIndex = WallAlphas.Num() - 1;
				AlphaIndex > 0;
				--AlphaIndex
				)
			{
				if (
					FMath::IsNearlyEqual(
						WallAlphas[AlphaIndex],
						WallAlphas[AlphaIndex - 1]
					)
					)
				{
					WallAlphas.RemoveAt(AlphaIndex);
				}
			}

			TArray<FVector> WallBottomPoints;
			TArray<FVector> WallShoulderPoints;
			TArray<FVector> WallTopPoints;
			TArray<FVector> WallNormals;

			for (const float WallAlpha : WallAlphas)
			{
				const FVector2D OriginalPoint = FMath::Lerp(
					OriginalBottomA,
					OriginalBottomB,
					WallAlpha
				);
				FVector2D RoundedNormal2D;
				const FVector2D RoundedPoint =
					RoundConvexPoint(
						OriginalPoint,
						&RoundedNormal2D
					);
				FVector2D TopPoint = RoundedPoint;

				if (bUseWavyLip)
				{
					TopPoint += GetCliffEdgeOffset(OriginalPoint);
				}

				const FVector WallNormal =
					RoundedNormal2D.SizeSquared() <= SMALL_NUMBER
					? Wall.Normal
					: FVector(
						RoundedNormal2D.X,
						RoundedNormal2D.Y,
						0.0f
					);
				float WallTopZ =
					(GridPosition.Z + 1) * SafeGridSize;

				if (!bCoveredAbove)
				{
					FVector IgnoredTopNormal;
					WallTopZ = GetContinuousTopSurfaceZ(
						OriginalPoint.X,
						OriginalPoint.Y,
						GridPosition.Z + 1,
						IgnoredTopNormal
					);
				}

				const float WallShoulderZ =
					bUseWavyLip
					? FMath::Max(
						BlockMinimum.Z,
						WallTopZ - ChamferDepth
					)
					: WallTopZ;

				WallBottomPoints.Add(
					FVector(
						RoundedPoint.X,
						RoundedPoint.Y,
						BlockMinimum.Z
					)
				);
				WallShoulderPoints.Add(
					FVector(
						RoundedPoint.X,
						RoundedPoint.Y,
						WallShoulderZ
					)
				);
				WallTopPoints.Add(
					FVector(
						TopPoint.X,
						TopPoint.Y,
						WallTopZ
					)
				);
				WallNormals.Add(WallNormal);
			}

			for (
				int32 WallPointIndex = 0;
				WallPointIndex < WallBottomPoints.Num() - 1;
				++WallPointIndex
				)
			{
				if (bUseWavyLip)
				{
					AddContinuousWallQuad(
						Section,
						WallBottomPoints[WallPointIndex],
						WallBottomPoints[WallPointIndex + 1],
						WallShoulderPoints[WallPointIndex + 1],
						WallShoulderPoints[WallPointIndex],
						WallNormals[WallPointIndex],
						WallNormals[WallPointIndex + 1],
						SafeGridSize
					);
					AddContinuousWallQuad(
						Section,
						WallShoulderPoints[WallPointIndex],
						WallShoulderPoints[WallPointIndex + 1],
						WallTopPoints[WallPointIndex + 1],
						WallTopPoints[WallPointIndex],
						WallNormals[WallPointIndex],
						WallNormals[WallPointIndex + 1],
						SafeGridSize
					);
				}
				else
				{
					AddContinuousWallQuad(
						Section,
						WallBottomPoints[WallPointIndex],
						WallBottomPoints[WallPointIndex + 1],
						WallTopPoints[WallPointIndex + 1],
						WallTopPoints[WallPointIndex],
						WallNormals[WallPointIndex],
						WallNormals[WallPointIndex + 1],
						SafeGridSize
					);
				}
			}
		}

		// A three-block L around one missing cell is a concave cliff corner.
		// The two planar walls stop at tangent points and this curved strip fills
		// the notch without changing the occupied-block source data.
		for (int32 CornerX = 0; CornerX <= 1; ++CornerX)
		{
			for (int32 CornerY = 0; CornerY <= 1; ++CornerY)
			{
				const int32 XDirection = CornerX == 0 ? -1 : 1;
				const int32 YDirection = CornerY == 0 ? -1 : 1;
				const FIntVector SideXPosition =
					GridPosition + FIntVector(XDirection, 0, 0);
				const FIntVector SideYPosition =
					GridPosition + FIntVector(0, YDirection, 0);
				const FIntVector MissingDiagonalPosition =
					GridPosition +
					FIntVector(XDirection, YDirection, 0);

				if (
					!IsContinuousSurfaceBlock(SideXPosition) ||
					!IsContinuousSurfaceBlock(SideYPosition) ||
					HasBlock(MissingDiagonalPosition)
					)
				{
					continue;
				}

				const int32 CornerGridX =
					GridPosition.X + CornerX;
				const int32 CornerGridY =
					GridPosition.Y + CornerY;

				if (
					!IsRoundableConcaveCorner(
						CornerGridX,
						CornerGridY,
						GridPosition.Z
					)
					)
				{
					continue;
				}

				const FVector2D CornerPoint(
					CornerGridX * SafeGridSize,
					CornerGridY * SafeGridSize
				);
				const FVector2D CircleCenter =
					CornerPoint +
					FVector2D(
						XDirection * CornerRadius,
						YDirection * CornerRadius
					);
				const bool bCoveredAbove =
					HasBlock(GridPosition + FIntVector(0, 0, 1));
				TArray<FVector> ArcBottomPoints;
				TArray<FVector> ArcTopPoints;
				TArray<FVector> ArcWallNormals;
				TArray<FVector> ArcTopNormals;

				for (
					int32 CornerStep = 0;
					CornerStep <= CornerSubdivisions;
					++CornerStep
					)
				{
					const float Alpha =
						static_cast<float>(CornerStep) /
						static_cast<float>(CornerSubdivisions);
					const FVector2D CircleDirection =
						FVector2D(
							-XDirection * (1.0f - Alpha),
							-YDirection * Alpha
						).GetSafeNormal();
					const FVector2D ArcPoint =
						CircleCenter +
						(CircleDirection * CornerRadius);
					const FVector WallNormal(
						-CircleDirection.X,
						-CircleDirection.Y,
						0.0f
					);
					float ArcTopZ =
						(GridPosition.Z + 1) * SafeGridSize;
					FVector ArcTopNormal = FVector::UpVector;

					if (!bCoveredAbove)
					{
						ArcTopZ -= ChamferDepth;
						GetContinuousTopSurfaceZ(
							ArcPoint.X,
							ArcPoint.Y,
							GridPosition.Z + 1,
							ArcTopNormal
						);
					}

					ArcBottomPoints.Add(
						FVector(
							ArcPoint.X,
							ArcPoint.Y,
							BlockMinimum.Z
						)
					);
					ArcTopPoints.Add(
						FVector(
							ArcPoint.X,
							ArcPoint.Y,
							ArcTopZ
						)
					);
					ArcWallNormals.Add(WallNormal);
					ArcTopNormals.Add(ArcTopNormal);
				}

				for (
					int32 ArcIndex = 0;
					ArcIndex < ArcBottomPoints.Num() - 1;
					++ArcIndex
					)
				{
					AddContinuousWallQuad(
						Section,
						ArcBottomPoints[ArcIndex],
						ArcBottomPoints[ArcIndex + 1],
						ArcTopPoints[ArcIndex + 1],
						ArcTopPoints[ArcIndex],
						ArcWallNormals[ArcIndex],
						ArcWallNormals[ArcIndex + 1],
						SafeGridSize
					);
				}

				if (!bCoveredAbove)
				{
					FVector CornerTopNormal;
					GetContinuousTopSurfaceZ(
						CornerPoint.X,
						CornerPoint.Y,
						GridPosition.Z + 1,
						CornerTopNormal
					);
					const float CornerTopZ =
						(GridPosition.Z + 1) * SafeGridSize -
						ChamferDepth;
					const FVector CornerTopPoint(
						CornerPoint.X,
						CornerPoint.Y,
						CornerTopZ
					);

					for (
						int32 ArcIndex = 0;
						ArcIndex < ArcTopPoints.Num() - 1;
						++ArcIndex
						)
					{
						AddContinuousTriangle(
							Section,
							CornerTopPoint,
							ArcTopPoints[ArcIndex],
							ArcTopPoints[ArcIndex + 1],
							CornerTopNormal,
							ArcTopNormals[ArcIndex],
							ArcTopNormals[ArcIndex + 1],
							FVector::UpVector,
							SafeGridSize
						);
					}
				}

				if (
					GridPosition.Z > 0 &&
					!HasBlock(
						GridPosition + FIntVector(0, 0, -1)
					) &&
					!HasBlock(
						MissingDiagonalPosition +
						FIntVector(0, 0, -1)
					)
					)
				{
					const FVector CornerBottomPoint(
						CornerPoint.X,
						CornerPoint.Y,
						BlockMinimum.Z
					);

					for (
						int32 ArcIndex = 0;
						ArcIndex < ArcBottomPoints.Num() - 1;
						++ArcIndex
						)
					{
						AddContinuousTriangle(
							Section,
							CornerBottomPoint,
							ArcBottomPoints[ArcIndex],
							ArcBottomPoints[ArcIndex + 1],
							-FVector::UpVector,
							-FVector::UpVector,
							-FVector::UpVector,
							-FVector::UpVector,
							SafeGridSize
						);
					}
				}
			}
		}
	}

	if (SectionsByTileType.Num() == 0)
	{
		return;
	}

	UProceduralMeshComponent* ContinuousComponent =
		FindOrCreateContinuousChunkComponent(ChunkCoordinate);

	if (!ContinuousComponent)
	{
		return;
	}

	TArray<int32> TileTypes;
	SectionsByTileType.GetKeys(TileTypes);
	TileTypes.Sort();

	for (int32 SectionIndex = 0; SectionIndex < TileTypes.Num(); ++SectionIndex)
	{
		const int32 TileType = TileTypes[SectionIndex];
		FTileMapContinuousSection* Section =
			SectionsByTileType.Find(TileType);

		if (
			!Section ||
			Section->Vertices.Num() == 0 ||
			Section->Triangles.Num() == 0
			)
		{
			continue;
		}

		ContinuousComponent->CreateMeshSection(
			SectionIndex,
			Section->Vertices,
			Section->Triangles,
			Section->Normals,
			Section->UV0,
			Section->VertexColors,
			Section->Tangents,
			bGenerateCollision
		);

		UMaterialInterface* Material =
			GetTileMaterialOverride(TileType);

		if (!Material)
		{
			UStaticMesh* TileMesh = GetTileMesh(TileType);
			Material = TileMesh ? TileMesh->GetMaterial(0) : nullptr;
		}

		if (Material)
		{
			ContinuousComponent->SetMaterial(
				SectionIndex,
				Material
			);
		}
	}

	ContinuousComponent->SetCollisionEnabled(
		bGenerateCollision
		? ECollisionEnabled::QueryAndPhysics
		: ECollisionEnabled::NoCollision
	);
	ContinuousComponent->MarkRenderStateDirty();
}

UHierarchicalInstancedStaticMeshComponent*
ATileMapTerrainActor::FindOrCreateChunkComponent(
	const FIntVector& ChunkCoordinate,
	int32 TileType
)
{
	const int32 SafeTileType =
		ClampTileType(TileType);

	const FTileMapChunkMeshKey Key(
		ChunkCoordinate,
		SafeTileType
	);

	UHierarchicalInstancedStaticMeshComponent**
		ExistingComponent =
		ChunkComponentLookup.Find(Key);

	if (
		ExistingComponent &&
		IsValid(*ExistingComponent)
		)
	{
		return *ExistingComponent;
	}

	UStaticMesh* TileMesh =
		GetTileMesh(SafeTileType);

	if (!TileMesh)
	{
		return nullptr;
	}

	const FName ComponentName =
		MakeUniqueObjectName(
			this,
			UHierarchicalInstancedStaticMeshComponent::StaticClass(),
			FName(
				*FString::Printf(
					TEXT("TileChunk_%d_%d_%d_Type_%d"),
					ChunkCoordinate.X,
					ChunkCoordinate.Y,
					ChunkCoordinate.Z,
					SafeTileType
				)
			)
		);

	UHierarchicalInstancedStaticMeshComponent* NewComponent =
		NewObject<UHierarchicalInstancedStaticMeshComponent>(
			this,
			ComponentName,
			RF_Transient |
			RF_DuplicateTransient |
			RF_TextExportTransient
		);

	if (!NewComponent)
	{
		return nullptr;
	}

	// These components are only a render/collision cache. Persistent edits and
	// Undo/Redo live in the serialized block arrays above.
	NewComponent->ClearFlags(RF_Transactional);
	NewComponent->CreationMethod =
		EComponentCreationMethod::Instance;

	NewComponent->SetupAttachment(SceneRoot);
	NewComponent->SetRelativeTransform(FTransform::Identity);
	NewComponent->SetMobility(EComponentMobility::Movable);
	NewComponent->SetStaticMesh(TileMesh);
	NewComponent->SetGenerateOverlapEvents(false);
	NewComponent->SetCollisionProfileName(TEXT("BlockAll"));
	NewComponent->SetCastShadow(true);
	NewComponent->bCastStaticShadow = false;
	NewComponent->bCastDynamicShadow = true;

	UMaterialInterface* MaterialOverride =
		GetTileMaterialOverride(SafeTileType);

	if (MaterialOverride)
	{
		NewComponent->SetMaterial(0, MaterialOverride);
	}

	NewComponent->SetCollisionEnabled(
		bGenerateCollision
		? ECollisionEnabled::QueryAndPhysics
		: ECollisionEnabled::NoCollision
	);

	AddOwnedComponent(NewComponent);
	NewComponent->RegisterComponent();

	ChunkComponents.Add(NewComponent);
	ChunkComponentLookup.Add(Key, NewComponent);

	return NewComponent;
}

void ATileMapTerrainActor::DestroyChunkComponents(
	const FIntVector& ChunkCoordinate
)
{
	TArray<FTileMapChunkMeshKey> KeysToRemove;

	for (
		const TPair<
			FTileMapChunkMeshKey,
			UHierarchicalInstancedStaticMeshComponent*
		>& Pair : ChunkComponentLookup
		)
	{
		if (
			Pair.Key.ChunkCoordinate ==
			ChunkCoordinate
			)
		{
			KeysToRemove.Add(Pair.Key);
		}
	}

	for (const FTileMapChunkMeshKey& Key : KeysToRemove)
	{
		UHierarchicalInstancedStaticMeshComponent**
			ExistingComponent =
			ChunkComponentLookup.Find(Key);

		UHierarchicalInstancedStaticMeshComponent*
			ComponentToRemove =
			ExistingComponent
			? *ExistingComponent
			: nullptr;

		ChunkComponentLookup.Remove(Key);
		ChunkComponents.RemoveSingleSwap(ComponentToRemove);

		if (IsValid(ComponentToRemove))
		{
			ComponentToRemove->ClearInstances();
			RemoveInstanceComponent(ComponentToRemove);
			RemoveOwnedComponent(ComponentToRemove);
			ComponentToRemove->DestroyComponent();
		}
	}

	UProceduralMeshComponent** ExistingContinuousComponent =
		ContinuousChunkComponentLookup.Find(ChunkCoordinate);

	UProceduralMeshComponent* ContinuousComponentToRemove =
		ExistingContinuousComponent
		? *ExistingContinuousComponent
		: nullptr;

	ContinuousChunkComponentLookup.Remove(ChunkCoordinate);
	ContinuousChunkComponents.RemoveSingleSwap(
		ContinuousComponentToRemove
	);

	if (IsValid(ContinuousComponentToRemove))
	{
		ContinuousComponentToRemove->ClearAllMeshSections();
		RemoveInstanceComponent(ContinuousComponentToRemove);
		RemoveOwnedComponent(ContinuousComponentToRemove);
		ContinuousComponentToRemove->DestroyComponent();
	}
}

void ATileMapTerrainActor::RebuildChunk(
	const FIntVector& ChunkCoordinate
)
{
	DestroyChunkComponents(ChunkCoordinate);

	const TArray<FIntVector>* ChunkBlocks =
		ChunkBlocksLookup.Find(ChunkCoordinate);

	if (!ChunkBlocks || ChunkBlocks->Num() == 0)
	{
		return;
	}

	if (bUseContinuousTerrainPrototype)
	{
		BuildContinuousChunk(
			ChunkCoordinate,
			*ChunkBlocks
		);
	}

	TMap<int32, TArray<FIntVector>> BlocksByTileType;

	for (const FIntVector& GridPosition : *ChunkBlocks)
	{
		const int32 TileType = GetBlockTileType(GridPosition);

		if (
			bUseContinuousTerrainPrototype &&
			!UsesLegacyMeshInContinuousMode(TileType)
			)
		{
			continue;
		}

		BlocksByTileType.FindOrAdd(
			TileType
		).Add(GridPosition);
	}

	for (
		const TPair<int32, TArray<FIntVector>>& Pair :
		BlocksByTileType
		)
	{
		UHierarchicalInstancedStaticMeshComponent*
			ChunkComponent =
			FindOrCreateChunkComponent(
				ChunkCoordinate,
				Pair.Key
			);

		if (!ChunkComponent)
		{
			continue;
		}

		ChunkComponent->SetMobility(
			EComponentMobility::Movable
		);

		ChunkComponent->SetCollisionEnabled(
			bGenerateCollision
			? ECollisionEnabled::QueryAndPhysics
			: ECollisionEnabled::NoCollision
		);

		// One synchronous HISM tree build per affected tile group.
		ChunkComponent->bAutoRebuildTreeOnInstanceChanges = false;
		ChunkComponent->ClearInstances();

		for (const FIntVector& GridPosition : Pair.Value)
		{
			ChunkComponent->AddInstance(
				GetBlockLocalTransform(GridPosition)
			);
		}

		ChunkComponent->BuildTreeIfOutdated(false, true);
		ChunkComponent->bAutoRebuildTreeOnInstanceChanges = true;
		ChunkComponent->MarkRenderStateDirty();
	}
}

void ATileMapTerrainActor::DestroyAllChunkComponents()
{
	// Query the actor too, removing caches left by older plugin revisions.
	TInlineComponentArray<
		UHierarchicalInstancedStaticMeshComponent*
	> ExistingComponents(this);

	for (
		UHierarchicalInstancedStaticMeshComponent* ChunkComponent :
		ExistingComponents
		)
	{
		if (
			!IsValid(ChunkComponent) ||
			!ChunkComponent->GetName().StartsWith(TEXT("TileChunk_"))
			)
		{
			continue;
		}

		ChunkComponent->ClearInstances();
		RemoveInstanceComponent(ChunkComponent);
		RemoveOwnedComponent(ChunkComponent);
		ChunkComponent->DestroyComponent();
	}

	ChunkComponents.Reset();
	ChunkComponentLookup.Reset();

	TInlineComponentArray<UProceduralMeshComponent*>
		ExistingContinuousComponents(this);

	for (
		UProceduralMeshComponent* ContinuousComponent :
		ExistingContinuousComponents
		)
	{
		if (
			!IsValid(ContinuousComponent) ||
			!ContinuousComponent->GetName().StartsWith(
				TEXT("TileContinuousChunk_")
			)
			)
		{
			continue;
		}

		ContinuousComponent->ClearAllMeshSections();
		RemoveInstanceComponent(ContinuousComponent);
		RemoveOwnedComponent(ContinuousComponent);
		ContinuousComponent->DestroyComponent();
	}

	ContinuousChunkComponents.Reset();
	ContinuousChunkComponentLookup.Reset();
}

void ATileMapTerrainActor::RebuildAllChunks()
{
	DestroyAllChunkComponents();
	RebuildDerivedLookups();
	ResolveAllAutoTiles();

	TArray<FIntVector> RequiredChunks;
	ChunkBlocksLookup.GetKeys(RequiredChunks);

	for (const FIntVector& ChunkCoordinate : RequiredChunks)
	{
		RebuildChunk(ChunkCoordinate);
	}
}
