ReditusProjectExporter v1
=========================

Target: Unreal Engine 4.27.x
Type: Editor-only plugin

INSTALL INTO YOUR EXISTING PLUGIN
---------------------------------
You already created:
<Project>/Plugins/ReditusProjectExporter/

Replace the generated plugin files with these files:

ReditusProjectExporter.uplugin
Source/ReditusProjectExporter/ReditusProjectExporter.Build.cs
Source/ReditusProjectExporter/Public/ReditusProjectExporter.h
Source/ReditusProjectExporter/Private/ReditusProjectExporter.cpp

If the blank plugin generated differently named .h/.cpp files, delete those old module source files so you do not end up with duplicate IMPLEMENT_MODULE definitions.

BUILD
-----
1. Close Unreal Editor.
2. Right-click your .uproject -> Generate Visual Studio project files.
3. Open the .sln.
4. Build Development Editor / Win64 for your game project.
5. Launch UE4.27.2.

USE
---
In Unreal Editor:
Window -> Export Project For Analysis

Output:
<Project>/ReditusProjectDump/

The exporter deletes/recreates ONLY that generated ReditusProjectDump folder.
It does not modify game assets.

SEND BACK
---------
Zip the entire ReditusProjectDump directory and upload it.

V1 EXPORTS
----------
- ProjectManifest.json
- Assets.json
- Dependencies.json
- Blueprint graph JSON:
  - variables
  - SCS component names
  - event graphs
  - function graphs
  - macro graphs
  - delegate graphs
  - node titles/classes/GUIDs/positions
  - pins/default values/links
- Data Tables as CSV
- User-defined enums
- User-defined structs
- Project Source text
- Config text
- Project plugin source/manifests/text
- .uproject

NOT YET SPECIALIZED IN V1
-------------------------
- Dialogue Plugin tree semantics
- Level actor placement/property dump
- Material graph specialization
- Behavior Tree specialization
- Animation state-machine specialization
- Level Sequence specialization
- Generic DataAsset property export

We add those after v1 successfully compiles and exports the project.
